Примечание к исходному результату: в feedback есть противоречия входным данным — указаны «4 года» Python и отсутствие Redis Cluster, хотя резюме содержит опыт с июня 2018 года и Redis Cluster. Текст модели сохранён без исправления. Статус succeeded не гарантирует фактическую корректность.

# Оценка для рекрутера

Оценка AI и решение человека разделены. Решение рекрутера и нанимающего менеджера в исходных материалах не зафиксировано.

Сохранённая общая оценка (`overall_readiness`): **0.96875**; это исходная шкала, не балл из 10.

Уверенность: 1.0; покрытие: 1.0.

| Направление | Значение | Уверенность | Покрытие |

|---|---:|---:|---:|

| Технические компетенции | 1.0 | 1.0 | 1.0 |

| Работа в команде | 1.0 | 1.0 | 1.0 |

| Ответственность за результат | 0.875 | 1.0 | 1.0 |

| Соответствие вакансии | 1.0 | 1.0 | 1.0 |


Полный профиль с основаниями и ссылками на evidence:

```json

{
  "schema_version": "candidate_profile_v1",
  "selected_assessment_artifact_ids": [
    "06c8b179-0bcf-4503-adf4-36b4572350e1",
    "49f3b4bf-7735-413a-ab8f-9daf0a8009db",
    "67481e30-8711-4580-a28d-48dc59d914bc",
    "cd91922c-f565-4428-9413-7842d5ecd240"
  ],
  "resume_positions": [
    {
      "position_id": "1",
      "employer": "BetaSoft",
      "role": "Python-разработчик",
      "period": "июнь 2018 — август 2021",
      "project": "REST-платформа обработки заказов",
      "responsibilities": [
        "разработка Django REST API",
        "проектирование схем PostgreSQL",
        "оптимизация SQL",
        "контейнеризация в Docker",
        "участие в code review и настройке GitLab CI/CD"
      ],
      "skills": [
        "Python",
        "Django",
        "PostgreSQL",
        "SQL",
        "Docker",
        "GitLab CI/CD"
      ],
      "achievements": [
        "сократил p95 ответа API с 900 до 320 мс после профилирования Python-кода и SQL."
      ],
      "evidence_ids": [
        "resume:002",
        "resume:003",
        "resume:004",
        "resume:005",
        "resume:006",
        "resume:007",
        "resume:008",
        "resume:009",
        "resume:010",
        "resume:011"
      ]
    },
    {
      "position_id": "2",
      "employer": "StreamWorks",
      "role": "Middle Python Developer",
      "period": "сентябрь 2021 — настоящее время",
      "project": "высоконагруженная событийная платформа",
      "responsibilities": [
        "разработка FastAPI-микросервисов",
        "Kafka producers и consumers",
        "внедрение transactional outbox",
        "идемпотентности",
        "Event Sourcing и CQRS в сервисе статусов",
        "ETL из PostgreSQL в ClickHouse",
        "деплой в Kubernetes",
        "мониторинг Prometheus и Grafana",
        "алерты и разбор инцидентов",
        "code review"
      ],
      "skills": [
        "Python",
        "FastAPI",
        "Kafka",
        "Event Sourcing",
        "CQRS",
        "PostgreSQL",
        "ClickHouse",
        "Kubernetes",
        "Prometheus",
        "Grafana"
      ],
      "achievements": [
        "снизил долю повторно обработанных событий с 1,8% до 0,03% добавив idempotency key, retry с backoff и dead-letter topic.",
        "Настроил gRPC между двумя внутренними сервисами и Redis Cluster для кэша справочников.",
        "Регулярно писал ADR и согласовывал изменения контрактов с соседними командами."
      ],
      "evidence_ids": [
        "resume:012",
        "resume:013",
        "resume:014",
        "resume:015",
        "resume:016",
        "resume:017",
        "resume:018",
        "resume:019",
        "resume:020",
        "resume:021",
        "resume:022",
        "resume:023",
        "resume:024",
        "resume:025",
        "resume:026",
        "resume:027"
      ]
    }
  ],
  "resume_claims": [
    {
      "claim_id": "claim_1",
      "claim_type": "experience",
      "subject": "Опыт работы с Python от 5 лет",
      "evidence_ids": [
        "resume:013",
        "resume:014"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_2",
      "claim_type": "experience",
      "subject": "Опыт разработки REST API с использованием Django/FastAPI",
      "evidence_ids": [
        "resume:006",
        "resume:017"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_3",
      "claim_type": "experience",
      "subject": "Проектирование и поддержка микросервисной архитектуры",
      "evidence_ids": [
        "resume:017"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_4",
      "claim_type": "experience",
      "subject": "Проектирование схем PostgreSQL, оптимизация запросов",
      "evidence_ids": [
        "resume:007",
        "resume:008"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_5",
      "claim_type": "experience",
      "subject": "Опыт работы с Kafka (producers/consumers) в продакшене",
      "evidence_ids": [
        "resume:018"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_6",
      "claim_type": "experience",
      "subject": "Опыт разработки ETL процессов",
      "evidence_ids": [
        "resume:019"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_7",
      "claim_type": "experience",
      "subject": "Контейнеризация и оркестрация с Docker/Kubernetes",
      "evidence_ids": [
        "resume:009",
        "resume:021"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_8",
      "claim_type": "experience",
      "subject": "Опыт работы с ClickHouse",
      "evidence_ids": [
        "resume:020"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_9",
      "claim_type": "experience",
      "subject": "Настройка мониторинга (Prometheus, Grafana)",
      "evidence_ids": [
        "resume:021"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_10",
      "claim_type": "experience",
      "subject": "Опыт работы с CI/CD",
      "evidence_ids": [
        "resume:010"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_11",
      "claim_type": "skill",
      "subject": "Знание gRPC для межсервисного взаимодействия",
      "evidence_ids": [
        "resume:025"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_12",
      "claim_type": "experience",
      "subject": "Знание Domain-Driven Design (DDD)",
      "evidence_ids": [
        "resume:027"
      ],
      "verification_status": "unverified"
    }
  ],
  "criterion_summaries": [
    {
      "criterion_id": "collaboration",
      "dimension": "soft_skills",
      "value": 1.0,
      "confidence": 1.0,
      "observation_count": 4,
      "evidence_references": [
        "06c8b179-0bcf-4503-adf4-36b4572350e1:collaboration:0",
        "06c8b179-0bcf-4503-adf4-36b4572350e1:collaboration:1",
        "67481e30-8711-4580-a28d-48dc59d914bc:collaboration:0",
        "67481e30-8711-4580-a28d-48dc59d914bc:collaboration:1",
        "67481e30-8711-4580-a28d-48dc59d914bc:collaboration:2",
        "cd91922c-f565-4428-9413-7842d5ecd240:collaboration:0"
      ]
    },
    {
      "criterion_id": "ownership",
      "dimension": "corporate_competencies",
      "value": 0.875,
      "confidence": 1.0,
      "observation_count": 4,
      "evidence_references": [
        "06c8b179-0bcf-4503-adf4-36b4572350e1:ownership:0",
        "06c8b179-0bcf-4503-adf4-36b4572350e1:ownership:1",
        "49f3b4bf-7735-413a-ab8f-9daf0a8009db:ownership:0",
        "67481e30-8711-4580-a28d-48dc59d914bc:ownership:0",
        "67481e30-8711-4580-a28d-48dc59d914bc:ownership:1",
        "cd91922c-f565-4428-9413-7842d5ecd240:ownership:0"
      ]
    },
    {
      "criterion_id": "primary_vacancy_fit",
      "dimension": "vacancy_fit",
      "value": 1.0,
      "confidence": 1.0,
      "observation_count": 4,
      "evidence_references": [
        "06c8b179-0bcf-4503-adf4-36b4572350e1:primary_vacancy_fit:0",
        "06c8b179-0bcf-4503-adf4-36b4572350e1:primary_vacancy_fit:1",
        "06c8b179-0bcf-4503-adf4-36b4572350e1:primary_vacancy_fit:2",
        "49f3b4bf-7735-413a-ab8f-9daf0a8009db:primary_vacancy_fit:0",
        "49f3b4bf-7735-413a-ab8f-9daf0a8009db:primary_vacancy_fit:1",
        "67481e30-8711-4580-a28d-48dc59d914bc:primary_vacancy_fit:0",
        "67481e30-8711-4580-a28d-48dc59d914bc:primary_vacancy_fit:1",
        "cd91922c-f565-4428-9413-7842d5ecd240:primary_vacancy_fit:0"
      ]
    },
    {
      "criterion_id": "technical_depth",
      "dimension": "technical",
      "value": 1.0,
      "confidence": 1.0,
      "observation_count": 4,
      "evidence_references": [
        "06c8b179-0bcf-4503-adf4-36b4572350e1:technical_depth:0",
        "06c8b179-0bcf-4503-adf4-36b4572350e1:technical_depth:1",
        "06c8b179-0bcf-4503-adf4-36b4572350e1:technical_depth:2",
        "06c8b179-0bcf-4503-adf4-36b4572350e1:technical_depth:3",
        "49f3b4bf-7735-413a-ab8f-9daf0a8009db:technical_depth:0",
        "49f3b4bf-7735-413a-ab8f-9daf0a8009db:technical_depth:1",
        "49f3b4bf-7735-413a-ab8f-9daf0a8009db:technical_depth:2",
        "49f3b4bf-7735-413a-ab8f-9daf0a8009db:technical_depth:3",
        "49f3b4bf-7735-413a-ab8f-9daf0a8009db:technical_depth:4",
        "67481e30-8711-4580-a28d-48dc59d914bc:technical_depth:0",
        "67481e30-8711-4580-a28d-48dc59d914bc:technical_depth:1",
        "67481e30-8711-4580-a28d-48dc59d914bc:technical_depth:2",
        "67481e30-8711-4580-a28d-48dc59d914bc:technical_depth:3",
        "cd91922c-f565-4428-9413-7842d5ecd240:technical_depth:0"
      ]
    }
  ],
  "dimension_summaries": [
    {
      "dimension": "technical",
      "value": 1.0,
      "confidence": 1.0,
      "assessed_criteria": 1,
      "applicable_criteria": 1,
      "coverage": 1.0
    },
    {
      "dimension": "soft_skills",
      "value": 1.0,
      "confidence": 1.0,
      "assessed_criteria": 1,
      "applicable_criteria": 1,
      "coverage": 1.0
    },
    {
      "dimension": "corporate_competencies",
      "value": 0.875,
      "confidence": 1.0,
      "assessed_criteria": 1,
      "applicable_criteria": 1,
      "coverage": 1.0
    },
    {
      "dimension": "vacancy_fit",
      "value": 1.0,
      "confidence": 1.0,
      "assessed_criteria": 1,
      "applicable_criteria": 1,
      "coverage": 1.0
    }
  ],
  "overall_readiness": 0.96875,
  "overall_confidence": 1.0,
  "overall_coverage": 1.0,
  "strong_pool_eligible": true,
  "eligibility_reason_codes": [],
  "integrity_review_required": false,
  "compatibility_key": "ef39e7536624c89387da27adaed41a4c82e4ef19b06d87cf476ceb1b6ff8edc8",
  "is_hiring_decision": false
}

```


## Исходный результат `resume_relevance`

```json

{
  "schema_version": "session_agent_output_v2",
  "purpose": "resume_relevance",
  "positions": [
    {
      "position_id": "1",
      "employer": "BetaSoft",
      "role": "Python-разработчик",
      "period": "июнь 2018 — август 2021",
      "project": "REST-платформа обработки заказов",
      "responsibilities": [
        "разработка Django REST API",
        "проектирование схем PostgreSQL",
        "оптимизация SQL",
        "контейнеризация в Docker",
        "участие в code review и настройке GitLab CI/CD"
      ],
      "skills": [
        "Python",
        "Django",
        "PostgreSQL",
        "SQL",
        "Docker",
        "GitLab CI/CD"
      ],
      "achievements": [
        "сократил p95 ответа API с 900 до 320 мс после профилирования Python-кода и SQL."
      ],
      "evidence_ids": [
        "resume:002",
        "resume:003",
        "resume:004",
        "resume:005",
        "resume:006",
        "resume:007",
        "resume:008",
        "resume:009",
        "resume:010",
        "resume:011"
      ]
    },
    {
      "position_id": "2",
      "employer": "StreamWorks",
      "role": "Middle Python Developer",
      "period": "сентябрь 2021 — настоящее время",
      "project": "высоконагруженная событийная платформа",
      "responsibilities": [
        "разработка FastAPI-микросервисов",
        "Kafka producers и consumers",
        "внедрение transactional outbox",
        "идемпотентности",
        "Event Sourcing и CQRS в сервисе статусов",
        "ETL из PostgreSQL в ClickHouse",
        "деплой в Kubernetes",
        "мониторинг Prometheus и Grafana",
        "алерты и разбор инцидентов",
        "code review"
      ],
      "skills": [
        "Python",
        "FastAPI",
        "Kafka",
        "Event Sourcing",
        "CQRS",
        "PostgreSQL",
        "ClickHouse",
        "Kubernetes",
        "Prometheus",
        "Grafana"
      ],
      "achievements": [
        "снизил долю повторно обработанных событий с 1,8% до 0,03% добавив idempotency key, retry с backoff и dead-letter topic.",
        "Настроил gRPC между двумя внутренними сервисами и Redis Cluster для кэша справочников.",
        "Регулярно писал ADR и согласовывал изменения контрактов с соседними командами."
      ],
      "evidence_ids": [
        "resume:012",
        "resume:013",
        "resume:014",
        "resume:015",
        "resume:016",
        "resume:017",
        "resume:018",
        "resume:019",
        "resume:020",
        "resume:021",
        "resume:022",
        "resume:023",
        "resume:024",
        "resume:025",
        "resume:026",
        "resume:027"
      ]
    }
  ],
  "claims": [
    {
      "claim_id": "claim_1",
      "claim_type": "experience",
      "subject": "Опыт работы с Python от 5 лет",
      "evidence_ids": [
        "resume:013",
        "resume:014"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_2",
      "claim_type": "experience",
      "subject": "Опыт разработки REST API с использованием Django/FastAPI",
      "evidence_ids": [
        "resume:006",
        "resume:017"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_3",
      "claim_type": "experience",
      "subject": "Проектирование и поддержка микросервисной архитектуры",
      "evidence_ids": [
        "resume:017"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_4",
      "claim_type": "experience",
      "subject": "Проектирование схем PostgreSQL, оптимизация запросов",
      "evidence_ids": [
        "resume:007",
        "resume:008"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_5",
      "claim_type": "experience",
      "subject": "Опыт работы с Kafka (producers/consumers) в продакшене",
      "evidence_ids": [
        "resume:018"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_6",
      "claim_type": "experience",
      "subject": "Опыт разработки ETL процессов",
      "evidence_ids": [
        "resume:019"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_7",
      "claim_type": "experience",
      "subject": "Контейнеризация и оркестрация с Docker/Kubernetes",
      "evidence_ids": [
        "resume:009",
        "resume:021"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_8",
      "claim_type": "experience",
      "subject": "Опыт работы с ClickHouse",
      "evidence_ids": [
        "resume:020"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_9",
      "claim_type": "experience",
      "subject": "Настройка мониторинга (Prometheus, Grafana)",
      "evidence_ids": [
        "resume:021"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_10",
      "claim_type": "experience",
      "subject": "Опыт работы с CI/CD",
      "evidence_ids": [
        "resume:010"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_11",
      "claim_type": "skill",
      "subject": "Знание gRPC для межсервисного взаимодействия",
      "evidence_ids": [
        "resume:025"
      ],
      "verification_status": "unverified"
    },
    {
      "claim_id": "claim_12",
      "claim_type": "experience",
      "subject": "Знание Domain-Driven Design (DDD)",
      "evidence_ids": [
        "resume:027"
      ],
      "verification_status": "unverified"
    }
  ],
  "experience_matches": [
    {
      "experience_label": "Middle + Python Developer",
      "evidence_ids": [
        "resume:012",
        "resume:013",
        "resume:014"
      ],
      "requirement_id": "vacancy:001",
      "requirement_origin": "vacancy",
      "relevance": 1.0,
      "confidence": 1.0,
      "explanation": "Работа в качестве Middle Python Developer в StreamWorks с опытом разработки REST API на FastAPI соответствует требованиям вакансии.",
      "position_ids": [
        "2"
      ],
      "claim_ids": [
        "claim_1"
      ]
    },
    {
      "experience_label": "Python Developer",
      "evidence_ids": [
        "resume:002",
        "resume:003",
        "resume:004",
        "resume:005"
      ],
      "requirement_id": "vacancy:001",
      "requirement_origin": "vacancy",
      "relevance": 0.9,
      "confidence": 0.9,
      "explanation": "Работа на позиции Python-разработчика в BetaSoft и опыт разработки Django REST API также соответствуют требованиям вакансии.",
      "position_ids": [
        "1"
      ],
      "claim_ids": [
        "claim_2"
      ]
    },
    {
      "experience_label": "Контейнеризация и оркестрация",
      "evidence_ids": [
        "resume:009",
        "resume:021"
      ],
      "requirement_id": "vacancy:024",
      "requirement_origin": "vacancy",
      "relevance": 0.8,
      "confidence": 0.8,
      "explanation": "Опыт контейнеризации в Docker и деплой в Kubernetes подтверждают требования по оркестрации.",
      "position_ids": [
        "1",
        "2"
      ],
      "claim_ids": [
        "claim_7"
      ]
    },
    {
      "experience_label": "Проектирование ETL процессов",
      "evidence_ids": [
        "resume:019"
      ],
      "requirement_id": "vacancy:021",
      "requirement_origin": "vacancy",
      "relevance": 0.8,
      "confidence": 0.8,
      "explanation": "Опыт работы по созданию ETL из PostgreSQL в ClickHouse соответствует требованию вакансии.",
      "position_ids": [
        "2"
      ],
      "claim_ids": [
        "claim_6"
      ]
    },
    {
      "experience_label": "Настройка мониторинга",
      "evidence_ids": [
        "resume:021"
      ],
      "requirement_id": "vacancy:029",
      "requirement_origin": "vacancy",
      "relevance": 0.8,
      "confidence": 0.8,
      "explanation": "Опыт настройки мониторинга с использованием Prometheus и Grafana соответствует требованиям по мониторингу сервисов.",
      "position_ids": [
        "2"
      ],
      "claim_ids": [
        "claim_9"
      ]
    },
    {
      "experience_label": "Проектирование микросервисов",
      "evidence_ids": [
        "resume:017"
      ],
      "requirement_id": "vacancy:017",
      "requirement_origin": "vacancy",
      "relevance": 0.7,
      "confidence": 0.7,
      "explanation": "Опыт проектирования микросервисов в StreamWorks соответствует требованиям вакансии.",
      "position_ids": [
        "2"
      ],
      "claim_ids": [
        "claim_3"
      ]
    },
    {
      "experience_label": "Работа с Kafka",
      "evidence_ids": [
        "resume:018"
      ],
      "requirement_id": "vacancy:018",
      "requirement_origin": "vacancy",
      "relevance": 0.7,
      "confidence": 0.7,
      "explanation": "Опыт использования Kafka для обработки данных соответствует требованиям вакансии.",
      "position_ids": [
        "2"
      ],
      "claim_ids": [
        "claim_5"
      ]
    }
  ],
  "gaps": [
    "Опыт работы с Python от 5 лет не подтверждён, кандидат имеет 4 года по текущему резюме.",
    "Отсутствует упоминание о опыте работы с ELK Stack и Redis Cluster."
  ]
}

```


## Исходный результат `integrity_check`

```json

{
  "schema_version": "session_agent_output_v2",
  "purpose": "integrity_check",
  "observations": [
    {
      "status": "unverified_claim",
      "resume_evidence_id": "resume:001",
      "answer_evidence_id": null,
      "response_id": "1414dbc6-7367-4f0a-979f-2c2a2130268a",
      "explanation": "The candidate claims to have been working with Python commercially since June 2018, but this claim is not verified in the resume evidence catalog, which has different dates and experiences.",
      "clarification_question": "Can you provide further details about your experience in Python since June 2018?",
      "confidence": 0.0
    }
  ],
  "is_restriction": false
}

```


## Исходный результат `alternative_vacancy_match`

```json

{
  "schema_version": "session_agent_output_v2",
  "purpose": "alternative_vacancy_match",
  "target_vacancy_id": "702f6cd8-0ec2-4cad-b61f-e6f27929c2f0",
  "candidate_grade": "middle",
  "target_grade": "middle",
  "compatibility_status": "compatible",
  "fit_value": 1.0,
  "matched_criteria": [
    "collaboration",
    "ownership",
    "primary_vacancy_fit",
    "technical_depth"
  ],
  "matched_terms": [
    "Middle",
    "Python",
    "FastAPI",
    "Kafka",
    "ETL",
    "PostgreSQL",
    "ClickHouse",
    "Docker",
    "Kubernetes",
    "Prometheus",
    "Grafana"
  ],
  "gaps": [],
  "evidence_references": [
    "06c8b179-0bcf-4503-adf4-36b4572350e1:collaboration:0",
    "06c8b179-0bcf-4503-adf4-36b4572350e1:collaboration:1",
    "06c8b179-0bcf-4503-adf4-36b4572350e1:ownership:0",
    "06c8b179-0bcf-4503-adf4-36b4572350e1:ownership:1",
    "06c8b179-0bcf-4503-adf4-36b4572350e1:primary_vacancy_fit:0",
    "06c8b179-0bcf-4503-adf4-36b4572350e1:primary_vacancy_fit:1",
    "06c8b179-0bcf-4503-adf4-36b4572350e1:primary_vacancy_fit:2",
    "06c8b179-0bcf-4503-adf4-36b4572350e1:technical_depth:0",
    "06c8b179-0bcf-4503-adf4-36b4572350e1:technical_depth:1",
    "06c8b179-0bcf-4503-adf4-36b4572350e1:technical_depth:2",
    "06c8b179-0bcf-4503-adf4-36b4572350e1:technical_depth:3"
  ],
  "explanation": "The candidate's profile aligns closely with the Middle Data Platform Python Developer vacancy as it demonstrates extensive experience and qualifications in relevant technologies and skills including Python, FastAPI, Kafka, ETL, PostgreSQL, ClickHouse, Docker, Kubernetes, Prometheus, and Grafana, with evidence of effective collaboration, ownership, and technical depth."
}

```
