# Полный сохранённый комплект PY-007

MAS-прогон 6 сентября не завершён. Секции явно разделяют оценку классификатора и фактически сохранённые этапы MAS.

## Полное резюме в MAS

СИНТЕТИЧЕСКОЕ РЕЗЮМЕ — не относится к реальному человеку.

Профессиональный профиль: Data analyst без backend-инженерии.
Место работы: Synthetic Product Lab.
Роль: разработчик или смежный специалист согласно описанию опыта.
Опыт и стек: 4 года аналитики в Python/Jupyter, без production backend.


## Вакансия MAS

Middle + Python Developer
Уровень должности: Middle
Тип занятости: Полная занятость
Зарплата: Не указана
Опыт работы: от 3 лет коммерческой разработки
Регионы показа вакансии: Санкт-Петербург/ Челябинск

Обязанности:
● Разработка и поддержка высоконагруженных микросервисов;
● Интеграция с Kafka для обработки потоков данных;
● Проектирование Event Sourcing и CQRS паттернов;
● Разработка API для межсервисного взаимодействия;
● Настройка мониторинга и алертинга сервисов;
● Участие в Code review.

Требования:
● Опыт работы с Python от 5 лет;
● Django/FastAPI - опыт разработки REST API;
● Микросервисная архитектура - опыт проектирования и поддержки;
● Apache Kafka - продакшн опыт работы с producers/consumers;
● PostgreSQL - проектирование схем, оптимизация запросов;
● ETL процессы - Extract, Transform, Load данных;
● Docker/Kubernetes - контейнеризация и оркестрация;
● Базы данных: PostgreSQL, ClickHouse;
● Event-driven архитектура - паттерны работы с событиями;
● API Gateway - опыт интеграции через шлюзы;
● Мониторинг: Prometheus, Grafana или аналоги;
● Git, CI/CD - DevOps практики.

Будет плюсом:
● Знание gRPC для межсервисного взаимодействия;
● Опыт с ELK Stack (Elasticsearch, Logstash, Kibana);
● Redis Cluster для высокодоступного кэширования;
● Знание Domain-Driven Design (DDD);
● Опыт performance tuning Python приложений.

Условия:
● Удаленная работа, гибкое начало и конец рабочего дня при синхронизации с командой.
● Индивидуальный план развития с возможностью освоения новых технологий.
● Насыщенная корпоративная жизнь.
● Оплата профильных конференций и профессиональной литературы.
● Доступ к курсам GIGASCHOOL.


# PY-007: Data analyst без backend-инженерии

Данные synthetic. Это отдельная проверка answer-assessment v2, не полный MAS-конвейер.

## Резюме в проверке классификатора

4 года аналитики в Python/Jupyter, без production backend.

## Вопрос

Опишите релевантный вакансии production-опыт: ваш личный вклад, архитектуру Python-сервиса, надёжность обработки сообщений, работу с PostgreSQL, контейнеризацию и наблюдаемость, а также измеримый результат; если опыта с обязательной технологией нет, скажите об этом прямо?

## Полный ответ

Четыре года использую Python в Jupyter для pandas и отчётов, но backend-сервисы не разрабатывал. Django, FastAPI, Kafka, Kubernetes и CI/CD не применял. Думаю, индекс в PostgreSQL нужно создавать на каждом столбце, тогда любой запрос ускорится без компромиссов. Для асинхронности достаточно добавить async перед любой блокирующей функцией. Production-метрик или примеров эксплуатации у меня нет.

## Оценка для рекрутера

Тестовый прогноз: **не подходит**. Эталон synthetic-датасета: не подходит. Решение человека не зафиксировано.

Основание эталонной разметки: Python используется не в требуемом контексте, присутствуют технические ошибки.

Оценка AI по ответу; `value` — исходное значение, `confidence` — уверенность модели.


**Технические компетенции** (`technical_depth`)

Метка: `contradicted`; значение: `-1.0`; уверенность: `0.9`.

Candidate states 4 years using Python in Jupyter for data analysis without backend service development, no experience with Django, FastAPI, Kafka, Kubernetes or CI/CD, and provides incorrect or overly simplified understanding of PostgreSQL indexing and async programming, lacking any production experience or metrics.


Evidence: `answer:a7a464d1-53cc-5c25-9a52-bfc84505628a:001` (counter).


> Четыре года использую Python в Jupyter для pandas и отчётов, но backend-сервисы не разрабатывал. Django, FastAPI, Kafka, Kubernetes и CI/CD не применял. Думаю, индекс в PostgreSQL нужно создавать на каждом столбце, тогда любой запрос ускорится без компромиссов. Для асинхронности достаточно добавить async перед любой блокирующей функцией. Production-метрик или примеров эксплуатации у меня нет.


**Соответствие вакансии** (`primary_vacancy_fit`)

Метка: `contradicted`; значение: `-1.0`; уверенность: `0.95`.

Candidate explicitly denies experience with critical required technologies including Django/FastAPI, Kafka, Kubernetes, CI/CD, and production backend services, thus not meeting mandatory vacancy requirements.


Evidence: `answer:a7a464d1-53cc-5c25-9a52-bfc84505628a:001` (counter).


> Четыре года использую Python в Jupyter для pandas и отчётов, но backend-сервисы не разрабатывал. Django, FastAPI, Kafka, Kubernetes и CI/CD не применял. Думаю, индекс в PostgreSQL нужно создавать на каждом столбце, тогда любой запрос ускорится без компромиссов. Для асинхронности достаточно добавить async перед любой блокирующей функцией. Production-метрик или примеров эксплуатации у меня нет.


Назначение `follow_up` из исходной оценки:

```json

[
  {
    "trigger": "missing_detail",
    "prompt": "Вы можете привести пример решения с реальным использованием PostgreSQL и описать, как обеспечивалась производительность и надёжность?",
    "reason": "Нехватка информации о реальном опыте с PostgreSQL и production-условиях",
    "criterion_ids": [
      "technical_depth"
    ],
    "requirement_ids": [
      "req-postgresql"
    ],
    "resume_claim_ids": []
  }
]

```

## Полный результат классификатора

```json

{
  "candidate_id": "PY-007",
  "profile": "Data analyst без backend-инженерии",
  "target": "не подходит",
  "target_reason": "Python используется не в требуемом контексте, присутствуют технические ошибки.",
  "prediction": "не подходит",
  "correct": true,
  "technical": {
    "label": "contradicted",
    "value": -1.0,
    "confidence": 0.9,
    "explanation": "Candidate states 4 years using Python in Jupyter for data analysis without backend service development, no experience with Django, FastAPI, Kafka, Kubernetes or CI/CD, and provides incorrect or overly simplified understanding of PostgreSQL indexing and async programming, lacking any production experience or metrics."
  },
  "vacancy_fit": {
    "label": "contradicted",
    "value": -1.0,
    "confidence": 0.95,
    "explanation": "Candidate explicitly denies experience with critical required technologies including Django/FastAPI, Kafka, Kubernetes, CI/CD, and production backend services, thus not meeting mandatory vacancy requirements."
  },
  "follow_up_count": 1,
  "follow_up": [
    "Вы можете привести пример решения с реальным использованием PostgreSQL и описать, как обеспечивалась производительность и надёжность?"
  ],
  "attempts": 1,
  "resume": "4 года аналитики в Python/Jupyter, без production backend.",
  "answer": "Четыре года использую Python в Jupyter для pandas и отчётов, но backend-сервисы не разрабатывал. Django, FastAPI, Kafka, Kubernetes и CI/CD не применял. Думаю, индекс в PostgreSQL нужно создавать на каждом столбце, тогда любой запрос ускорится без компромиссов. Для асинхронности достаточно добавить async перед любой блокирующей функцией. Production-метрик или примеров эксплуатации у меня нет.",
  "raw_assessment": {
    "schema_version": "session_agent_output_v2",
    "purpose": "answer_assessment",
    "response_id": "a7a464d1-53cc-5c25-9a52-bfc84505628a",
    "question_id": "cbdae577-cae3-5647-9900-f56fddf2f4c8",
    "observations": [
      {
        "criterion_id": "technical_depth",
        "dimension": "technical",
        "label": "contradicted",
        "value": -1.0,
        "confidence": 0.9,
        "explanation": "Candidate states 4 years using Python in Jupyter for data analysis without backend service development, no experience with Django, FastAPI, Kafka, Kubernetes or CI/CD, and provides incorrect or overly simplified understanding of PostgreSQL indexing and async programming, lacking any production experience or metrics.",
        "evidence": [
          {
            "kind": "counter",
            "evidence_id": "answer:a7a464d1-53cc-5c25-9a52-bfc84505628a:001"
          }
        ]
      },
      {
        "criterion_id": "primary_vacancy_fit",
        "dimension": "vacancy_fit",
        "label": "contradicted",
        "value": -1.0,
        "confidence": 0.95,
        "explanation": "Candidate explicitly denies experience with critical required technologies including Django/FastAPI, Kafka, Kubernetes, CI/CD, and production backend services, thus not meeting mandatory vacancy requirements.",
        "evidence": [
          {
            "kind": "counter",
            "evidence_id": "answer:a7a464d1-53cc-5c25-9a52-bfc84505628a:001"
          }
        ]
      }
    ],
    "follow_up": [
      {
        "trigger": "missing_detail",
        "prompt": "Вы можете привести пример решения с реальным использованием PostgreSQL и описать, как обеспечивалась производительность и надёжность?",
        "reason": "Нехватка информации о реальном опыте с PostgreSQL и production-условиях",
        "criterion_ids": [
          "technical_depth"
        ],
        "requirement_ids": [
          "req-postgresql"
        ],
        "resume_claim_ids": []
      }
    ],
    "live_coding": null
  }
}

```

# Вопросы, ответы и оценки



Ответы synthetic: это тестовые данные, не интервью реального кандидата.


В этом MAS-прогоне ответы не были сохранены. Результаты отдельного классификатора находятся в соседнем файле.

# Оценка для рекрутера

Оценка AI и решение человека разделены. Решение рекрутера и нанимающего менеджера в исходных материалах не зафиксировано.

Итоговый профиль MAS отсутствует: конвейер не дошёл до успешной финализации. Доступные оценки отдельных ответов сохранены отдельно.

# Фидбэк пользователю

Готовый фидбэк отсутствует: успешный артефакт candidate_feedback в этом прогоне не создан.
