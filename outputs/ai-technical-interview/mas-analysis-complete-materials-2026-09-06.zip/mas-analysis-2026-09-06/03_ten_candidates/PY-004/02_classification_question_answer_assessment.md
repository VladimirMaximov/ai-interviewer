# PY-004: Надёжные Python-микросервисы

Данные synthetic. Это отдельная проверка answer-assessment v2, не полный MAS-конвейер.

## Резюме в проверке классификатора

5,5 лет Python backend, Kafka/PostgreSQL, Docker/Kubernetes, observability.

## Вопрос

Опишите релевантный вакансии production-опыт: ваш личный вклад, архитектуру Python-сервиса, надёжность обработки сообщений, работу с PostgreSQL, контейнеризацию и наблюдаемость, а также измеримый результат; если опыта с обязательной технологией нет, скажите об этом прямо?

## Полный ответ

Пять с половиной лет работаю Python-разработчиком. Мой основной сервис был на Django REST Framework, фоновые интеграции — на FastAPI. Я отвечал за контракты Kafka, producer retries, идемпотентный consumer и DLQ. Для PostgreSQL переработал индексы и убрал N+1, ETL в ClickHouse запускался отдельным consumer. Контейнеры деплоил в Kubernetes через GitLab CI, мониторинг строил на Prometheus/Grafana. Число ошибок релиза снизилось на 35 процентов, p95 API — с 510 до 160 мс.

## Оценка для рекрутера

Тестовый прогноз: **подходит**. Эталон synthetic-датасета: подходит. Решение человека не зафиксировано.

Основание эталонной разметки: Полный стек подтверждён конкретным production-кейсом и метриками.

Оценка AI по ответу; `value` — исходное значение, `confidence` — уверенность модели.


**Технические компетенции** (`technical_depth`)

Метка: `strong`; значение: `1.0`; уверенность: `0.9`.

Candidate provides a detailed, technically correct description of production solutions including Django REST Framework service architecture, Kafka producers/consumers with retries and DLQ, PostgreSQL index optimization and N+1 removal, ETL with ClickHouse, container deployment with Kubernetes and GitLab CI, and monitoring with Prometheus/Grafana, along with measurable improvements in error reduction and latency.


Evidence: `answer:b2dcc376-fdfa-5bb9-b880-4de496d8b331:001` (supporting).


> Пять с половиной лет работаю Python-разработчиком. Мой основной сервис был на Django REST Framework, фоновые интеграции — на FastAPI. Я отвечал за контракты Kafka, producer retries, идемпотентный consumer и DLQ. Для PostgreSQL переработал индексы и убрал N+1, ETL в ClickHouse запускался отдельным consumer. Контейнеры деплоил в Kubernetes через GitLab CI, мониторинг строил на Prometheus/Grafana. Число ошибок релиза снизилось на 35 процентов, p95 API — с 510 до 160 мс.


**Соответствие вакансии** (`primary_vacancy_fit`)

Метка: `strong`; значение: `1.0`; уверенность: `0.9`.

Candidate explicitly matches all key mandatory vacancy requirements by describing 5.5 years commercial Python experience, use of Django REST Framework and FastAPI, handling high-load microservices with Kafka producers and consumers, PostgreSQL schema and query optimization, ETL with ClickHouse, containerization using Docker and Kubernetes, monitoring with Prometheus/Grafana, and CI/CD via GitLab, fulfilling the complete set of stated mandatory technologies.


Evidence: `answer:b2dcc376-fdfa-5bb9-b880-4de496d8b331:001` (supporting).


> Пять с половиной лет работаю Python-разработчиком. Мой основной сервис был на Django REST Framework, фоновые интеграции — на FastAPI. Я отвечал за контракты Kafka, producer retries, идемпотентный consumer и DLQ. Для PostgreSQL переработал индексы и убрал N+1, ETL в ClickHouse запускался отдельным consumer. Контейнеры деплоил в Kubernetes через GitLab CI, мониторинг строил на Prometheus/Grafana. Число ошибок релиза снизилось на 35 процентов, p95 API — с 510 до 160 мс.

## Полный результат классификатора

```json

{
  "candidate_id": "PY-004",
  "profile": "Надёжные Python-микросервисы",
  "target": "подходит",
  "target_reason": "Полный стек подтверждён конкретным production-кейсом и метриками.",
  "prediction": "подходит",
  "correct": true,
  "technical": {
    "label": "strong",
    "value": 1.0,
    "confidence": 0.9,
    "explanation": "Candidate provides a detailed, technically correct description of production solutions including Django REST Framework service architecture, Kafka producers/consumers with retries and DLQ, PostgreSQL index optimization and N+1 removal, ETL with ClickHouse, container deployment with Kubernetes and GitLab CI, and monitoring with Prometheus/Grafana, along with measurable improvements in error reduction and latency."
  },
  "vacancy_fit": {
    "label": "strong",
    "value": 1.0,
    "confidence": 0.9,
    "explanation": "Candidate explicitly matches all key mandatory vacancy requirements by describing 5.5 years commercial Python experience, use of Django REST Framework and FastAPI, handling high-load microservices with Kafka producers and consumers, PostgreSQL schema and query optimization, ETL with ClickHouse, containerization using Docker and Kubernetes, monitoring with Prometheus/Grafana, and CI/CD via GitLab, fulfilling the complete set of stated mandatory technologies."
  },
  "follow_up_count": 0,
  "follow_up": [],
  "attempts": 1,
  "resume": "5,5 лет Python backend, Kafka/PostgreSQL, Docker/Kubernetes, observability.",
  "answer": "Пять с половиной лет работаю Python-разработчиком. Мой основной сервис был на Django REST Framework, фоновые интеграции — на FastAPI. Я отвечал за контракты Kafka, producer retries, идемпотентный consumer и DLQ. Для PostgreSQL переработал индексы и убрал N+1, ETL в ClickHouse запускался отдельным consumer. Контейнеры деплоил в Kubernetes через GitLab CI, мониторинг строил на Prometheus/Grafana. Число ошибок релиза снизилось на 35 процентов, p95 API — с 510 до 160 мс.",
  "raw_assessment": {
    "schema_version": "session_agent_output_v2",
    "purpose": "answer_assessment",
    "response_id": "b2dcc376-fdfa-5bb9-b880-4de496d8b331",
    "question_id": "cbdae577-cae3-5647-9900-f56fddf2f4c8",
    "observations": [
      {
        "criterion_id": "technical_depth",
        "dimension": "technical",
        "label": "strong",
        "value": 1.0,
        "confidence": 0.9,
        "explanation": "Candidate provides a detailed, technically correct description of production solutions including Django REST Framework service architecture, Kafka producers/consumers with retries and DLQ, PostgreSQL index optimization and N+1 removal, ETL with ClickHouse, container deployment with Kubernetes and GitLab CI, and monitoring with Prometheus/Grafana, along with measurable improvements in error reduction and latency.",
        "evidence": [
          {
            "kind": "supporting",
            "evidence_id": "answer:b2dcc376-fdfa-5bb9-b880-4de496d8b331:001"
          }
        ]
      },
      {
        "criterion_id": "primary_vacancy_fit",
        "dimension": "vacancy_fit",
        "label": "strong",
        "value": 1.0,
        "confidence": 0.9,
        "explanation": "Candidate explicitly matches all key mandatory vacancy requirements by describing 5.5 years commercial Python experience, use of Django REST Framework and FastAPI, handling high-load microservices with Kafka producers and consumers, PostgreSQL schema and query optimization, ETL with ClickHouse, containerization using Docker and Kubernetes, monitoring with Prometheus/Grafana, and CI/CD via GitLab, fulfilling the complete set of stated mandatory technologies.",
        "evidence": [
          {
            "kind": "supporting",
            "evidence_id": "answer:b2dcc376-fdfa-5bb9-b880-4de496d8b331:001"
          }
        ]
      }
    ],
    "follow_up": null,
    "live_coding": null
  }
}

```
