# PY-005: Начинающий разработчик с ошибками в надёжности

Данные synthetic. Это отдельная проверка answer-assessment v2, не полный MAS-конвейер.

## Резюме в проверке классификатора

Около года учебной и коммерческой Python-разработки.

## Вопрос

Опишите релевантный вакансии production-опыт: ваш личный вклад, архитектуру Python-сервиса, надёжность обработки сообщений, работу с PostgreSQL, контейнеризацию и наблюдаемость, а также измеримый результат; если опыта с обязательной технологией нет, скажите об этом прямо?

## Полный ответ

На Python работаю около года. Небольшой API сделал на Flask. Kafka не использовал, но считаю, что для exactly-once достаточно подтвердить сообщение до обработки, тогда повторов не будет. Все события можно хранить в глобальном списке процесса. PostgreSQL, Kubernetes, ClickHouse и Prometheus в production не применял. Docker запускал локально, CI/CD для сервиса не настраивал.

## Оценка для рекрутера

Тестовый прогноз: **не подходит**. Эталон synthetic-датасета: не подходит. Решение человека не зафиксировано.

Основание эталонной разметки: Недостаточный стаж и конкретно неверные production-подходы.

Оценка AI по ответу; `value` — исходное значение, `confidence` — уверенность модели.


**Технические компетенции** (`technical_depth`)

Метка: `weak`; значение: `-0.5`; уверенность: `0.8`.

The candidate has about one year Python experience and made a small Flask API, which is not a production-level high-load service as required. Kafka was not used, and the explanation of exactly-once semantics is simplistic and imprecise, showing a lack of production message processing correctness. No practical production experience is given for PostgreSQL, Kubernetes, ClickHouse, Prometheus, Docker in production, or CI/CD. This demonstrates weak technical depth and incomplete production-level implementation knowledge.


Evidence: `answer:ff229078-5edf-59ff-a770-c396ad85d018:001` (counter).


> На Python работаю около года. Небольшой API сделал на Flask. Kafka не использовал, но считаю, что для exactly-once достаточно подтвердить сообщение до обработки, тогда повторов не будет. Все события можно хранить в глобальном списке процесса. PostgreSQL, Kubernetes, ClickHouse и Prometheus в production не применял. Docker запускал локально, CI/CD для сервиса не настраивал.


**Соответствие вакансии** (`primary_vacancy_fit`)

Метка: `weak`; значение: `-0.5`; уверенность: `0.9`.

The candidate does not meet the mandatory requirements of the vacancy such as 5+ years Python, FastAPI or Django experience, production Kafka, PostgreSQL schemas and optimization, production Docker and Kubernetes, Prometheus/Grafana monitoring, and CI/CD. They explicitly state lack of experience on most required stack components. Their only demonstrated experience is a small Flask API and limited local Docker usage, which insufficiently fits the vacancy.


Evidence: `answer:ff229078-5edf-59ff-a770-c396ad85d018:001` (counter).


> На Python работаю около года. Небольшой API сделал на Flask. Kafka не использовал, но считаю, что для exactly-once достаточно подтвердить сообщение до обработки, тогда повторов не будет. Все события можно хранить в глобальном списке процесса. PostgreSQL, Kubernetes, ClickHouse и Prometheus в production не применял. Docker запускал локально, CI/CD для сервиса не настраивал.


Назначение `follow_up` из исходной оценки:

```json

[
  {
    "trigger": "missing_detail",
    "prompt": "Можете ли вы подробнее описать ваш опыт с production-развёртыванием Python-сервисов, включая любые использованные инструменты контейнеризации, оркестрации и мониторинга?",
    "reason": "Недостаточно данных для оценки глубины технической реализации и соответствия требованиям вакансии.",
    "criterion_ids": [
      "technical_depth",
      "primary_vacancy_fit"
    ],
    "requirement_ids": [
      "req-platform",
      "req-observability"
    ],
    "resume_claim_ids": []
  }
]

```

## Полный результат классификатора

```json

{
  "candidate_id": "PY-005",
  "profile": "Начинающий разработчик с ошибками в надёжности",
  "target": "не подходит",
  "target_reason": "Недостаточный стаж и конкретно неверные production-подходы.",
  "prediction": "не подходит",
  "correct": true,
  "technical": {
    "label": "weak",
    "value": -0.5,
    "confidence": 0.8,
    "explanation": "The candidate has about one year Python experience and made a small Flask API, which is not a production-level high-load service as required. Kafka was not used, and the explanation of exactly-once semantics is simplistic and imprecise, showing a lack of production message processing correctness. No practical production experience is given for PostgreSQL, Kubernetes, ClickHouse, Prometheus, Docker in production, or CI/CD. This demonstrates weak technical depth and incomplete production-level implementation knowledge."
  },
  "vacancy_fit": {
    "label": "weak",
    "value": -0.5,
    "confidence": 0.9,
    "explanation": "The candidate does not meet the mandatory requirements of the vacancy such as 5+ years Python, FastAPI or Django experience, production Kafka, PostgreSQL schemas and optimization, production Docker and Kubernetes, Prometheus/Grafana monitoring, and CI/CD. They explicitly state lack of experience on most required stack components. Their only demonstrated experience is a small Flask API and limited local Docker usage, which insufficiently fits the vacancy."
  },
  "follow_up_count": 1,
  "follow_up": [
    "Можете ли вы подробнее описать ваш опыт с production-развёртыванием Python-сервисов, включая любые использованные инструменты контейнеризации, оркестрации и мониторинга?"
  ],
  "attempts": 1,
  "resume": "Около года учебной и коммерческой Python-разработки.",
  "answer": "На Python работаю около года. Небольшой API сделал на Flask. Kafka не использовал, но считаю, что для exactly-once достаточно подтвердить сообщение до обработки, тогда повторов не будет. Все события можно хранить в глобальном списке процесса. PostgreSQL, Kubernetes, ClickHouse и Prometheus в production не применял. Docker запускал локально, CI/CD для сервиса не настраивал.",
  "raw_assessment": {
    "schema_version": "session_agent_output_v2",
    "purpose": "answer_assessment",
    "response_id": "ff229078-5edf-59ff-a770-c396ad85d018",
    "question_id": "cbdae577-cae3-5647-9900-f56fddf2f4c8",
    "observations": [
      {
        "criterion_id": "technical_depth",
        "dimension": "technical",
        "label": "weak",
        "value": -0.5,
        "confidence": 0.8,
        "explanation": "The candidate has about one year Python experience and made a small Flask API, which is not a production-level high-load service as required. Kafka was not used, and the explanation of exactly-once semantics is simplistic and imprecise, showing a lack of production message processing correctness. No practical production experience is given for PostgreSQL, Kubernetes, ClickHouse, Prometheus, Docker in production, or CI/CD. This demonstrates weak technical depth and incomplete production-level implementation knowledge.",
        "evidence": [
          {
            "kind": "counter",
            "evidence_id": "answer:ff229078-5edf-59ff-a770-c396ad85d018:001"
          }
        ]
      },
      {
        "criterion_id": "primary_vacancy_fit",
        "dimension": "vacancy_fit",
        "label": "weak",
        "value": -0.5,
        "confidence": 0.9,
        "explanation": "The candidate does not meet the mandatory requirements of the vacancy such as 5+ years Python, FastAPI or Django experience, production Kafka, PostgreSQL schemas and optimization, production Docker and Kubernetes, Prometheus/Grafana monitoring, and CI/CD. They explicitly state lack of experience on most required stack components. Their only demonstrated experience is a small Flask API and limited local Docker usage, which insufficiently fits the vacancy.",
        "evidence": [
          {
            "kind": "counter",
            "evidence_id": "answer:ff229078-5edf-59ff-a770-c396ad85d018:001"
          }
        ]
      }
    ],
    "follow_up": [
      {
        "trigger": "missing_detail",
        "prompt": "Можете ли вы подробнее описать ваш опыт с production-развёртыванием Python-сервисов, включая любые использованные инструменты контейнеризации, оркестрации и мониторинга?",
        "reason": "Недостаточно данных для оценки глубины технической реализации и соответствия требованиям вакансии.",
        "criterion_ids": [
          "technical_depth",
          "primary_vacancy_fit"
        ],
        "requirement_ids": [
          "req-platform",
          "req-observability"
        ],
        "resume_claim_ids": []
      }
    ],
    "live_coding": null
  }
}

```
