# PY-001: Сильный event-driven backend

Данные synthetic. Это отдельная проверка answer-assessment v2, не полный MAS-конвейер.

## Резюме в проверке классификатора

6,5 лет Python backend: FastAPI, Kafka, PostgreSQL, ClickHouse, Kubernetes, Grafana.

## Вопрос

Опишите релевантный вакансии production-опыт: ваш личный вклад, архитектуру Python-сервиса, надёжность обработки сообщений, работу с PostgreSQL, контейнеризацию и наблюдаемость, а также измеримый результат; если опыта с обязательной технологией нет, скажите об этом прямо?

## Полный ответ

Коммерчески пишу на Python шесть с половиной лет. Лично спроектировал FastAPI-сервис обработки платежных событий: 14 микросервисов, Kafka producers и consumer groups, transactional outbox, идемпотентность по operation_id, retry и DLQ. PostgreSQL оптимизировал через EXPLAIN ANALYZE и индексы, ETL выгружал агрегаты в ClickHouse. Сервис разворачивал в Kubernetes через GitLab CI, добавил readiness probes, limits, Prometheus и Grafana. После изменений p95 снизился с 640 до 180 мс, повторная обработка — с 1,2 до 0,04 процента.

## Оценка для рекрутера

Тестовый прогноз: **подходит**. Эталон synthetic-датасета: подходит. Решение человека не зафиксировано.

Основание эталонной разметки: Подтверждены все основные обязательные технологии и личный результат.

Оценка AI по ответу; `value` — исходное значение, `confidence` — уверенность модели.


**Технические компетенции** (`technical_depth`)

Метка: `strong`; значение: `1.0`; уверенность: `0.9`.

Answer demonstrates detailed technical knowledge and experience with a production FastAPI microservices system including Kafka, PostgreSQL optimization, ETL, Kubernetes deployment, observability and measurable performance improvements.


Evidence: `answer:60a6f7db-9fc5-54e0-aa87-2c51cd0686d9:001` (supporting).


> Коммерчески пишу на Python шесть с половиной лет. Лично спроектировал FastAPI-сервис обработки платежных событий: 14 микросервисов, Kafka producers и consumer groups, transactional outbox, идемпотентность по operation_id, retry и DLQ. PostgreSQL оптимизировал через EXPLAIN ANALYZE и индексы, ETL выгружал агрегаты в ClickHouse. Сервис разворачивал в Kubernetes через GitLab CI, добавил readiness probes, limits, Prometheus и Grafana. После изменений p95 снизился с 640 до 180 мс, повторная обработка — с 1,2 до 0,04 процента.


**Соответствие вакансии** (`primary_vacancy_fit`)

Метка: `strong`; значение: `1.0`; уверенность: `0.9`.

Candidate meets or exceeds all mandatory vacancy requirements as evidenced by experience with 6.5 years Python, FastAPI REST API, high-load microservices, Kafka production usage, PostgreSQL schema and optimization, ETL with ClickHouse, Docker/Kubernetes, Prometheus/Grafana, and Git CI/CD.


Evidence: `answer:60a6f7db-9fc5-54e0-aa87-2c51cd0686d9:001` (supporting).


> Коммерчески пишу на Python шесть с половиной лет. Лично спроектировал FastAPI-сервис обработки платежных событий: 14 микросервисов, Kafka producers и consumer groups, transactional outbox, идемпотентность по operation_id, retry и DLQ. PostgreSQL оптимизировал через EXPLAIN ANALYZE и индексы, ETL выгружал агрегаты в ClickHouse. Сервис разворачивал в Kubernetes через GitLab CI, добавил readiness probes, limits, Prometheus и Grafana. После изменений p95 снизился с 640 до 180 мс, повторная обработка — с 1,2 до 0,04 процента.

## Полный результат классификатора

```json

{
  "candidate_id": "PY-001",
  "profile": "Сильный event-driven backend",
  "target": "подходит",
  "target_reason": "Подтверждены все основные обязательные технологии и личный результат.",
  "prediction": "подходит",
  "correct": true,
  "technical": {
    "label": "strong",
    "value": 1.0,
    "confidence": 0.9,
    "explanation": "Answer demonstrates detailed technical knowledge and experience with a production FastAPI microservices system including Kafka, PostgreSQL optimization, ETL, Kubernetes deployment, observability and measurable performance improvements."
  },
  "vacancy_fit": {
    "label": "strong",
    "value": 1.0,
    "confidence": 0.9,
    "explanation": "Candidate meets or exceeds all mandatory vacancy requirements as evidenced by experience with 6.5 years Python, FastAPI REST API, high-load microservices, Kafka production usage, PostgreSQL schema and optimization, ETL with ClickHouse, Docker/Kubernetes, Prometheus/Grafana, and Git CI/CD."
  },
  "follow_up_count": 0,
  "follow_up": [],
  "attempts": 1,
  "resume": "6,5 лет Python backend: FastAPI, Kafka, PostgreSQL, ClickHouse, Kubernetes, Grafana.",
  "answer": "Коммерчески пишу на Python шесть с половиной лет. Лично спроектировал FastAPI-сервис обработки платежных событий: 14 микросервисов, Kafka producers и consumer groups, transactional outbox, идемпотентность по operation_id, retry и DLQ. PostgreSQL оптимизировал через EXPLAIN ANALYZE и индексы, ETL выгружал агрегаты в ClickHouse. Сервис разворачивал в Kubernetes через GitLab CI, добавил readiness probes, limits, Prometheus и Grafana. После изменений p95 снизился с 640 до 180 мс, повторная обработка — с 1,2 до 0,04 процента.",
  "raw_assessment": {
    "schema_version": "session_agent_output_v2",
    "purpose": "answer_assessment",
    "response_id": "60a6f7db-9fc5-54e0-aa87-2c51cd0686d9",
    "question_id": "cbdae577-cae3-5647-9900-f56fddf2f4c8",
    "observations": [
      {
        "criterion_id": "technical_depth",
        "dimension": "technical",
        "label": "strong",
        "value": 1.0,
        "confidence": 0.9,
        "explanation": "Answer demonstrates detailed technical knowledge and experience with a production FastAPI microservices system including Kafka, PostgreSQL optimization, ETL, Kubernetes deployment, observability and measurable performance improvements.",
        "evidence": [
          {
            "kind": "supporting",
            "evidence_id": "answer:60a6f7db-9fc5-54e0-aa87-2c51cd0686d9:001"
          }
        ]
      },
      {
        "criterion_id": "primary_vacancy_fit",
        "dimension": "vacancy_fit",
        "label": "strong",
        "value": 1.0,
        "confidence": 0.9,
        "explanation": "Candidate meets or exceeds all mandatory vacancy requirements as evidenced by experience with 6.5 years Python, FastAPI REST API, high-load microservices, Kafka production usage, PostgreSQL schema and optimization, ETL with ClickHouse, Docker/Kubernetes, Prometheus/Grafana, and Git CI/CD.",
        "evidence": [
          {
            "kind": "supporting",
            "evidence_id": "answer:60a6f7db-9fc5-54e0-aa87-2c51cd0686d9:001"
          }
        ]
      }
    ],
    "follow_up": null,
    "live_coding": null
  }
}

```
