# Оценка для рекрутера

Оценка AI и решение человека разделены. Решение рекрутера и нанимающего менеджера в исходных материалах не зафиксировано.

Сохранённая общая оценка (`overall_readiness`): **0.8125**; это исходная шкала, не балл из 10.

Уверенность: 0.859375; покрытие: 1.0.

| Направление | Значение | Уверенность | Покрытие |

|---|---:|---:|---:|

| Технические компетенции | 1.0 | 0.9125 | 1.0 |

| Работа в команде | 0.75 | 0.8125 | 1.0 |

| Ответственность за результат | 1.0 | 0.9 | 1.0 |

| Соответствие вакансии | 0.5 | 0.8125 | 1.0 |


Полный профиль с основаниями и ссылками на evidence:

```json

{
  "schema_version": "candidate_profile_v2",
  "selected_assessment_artifact_ids": [
    "322b54dd-4ef1-40f2-9243-89338b1a4911",
    "4a3890ad-89be-409a-85fe-44d0ce2b2a03",
    "56013a9a-8b38-4bbd-bd8d-205424c6b1c4",
    "9b95903c-e999-4521-9abc-52f5d7fcbb4e"
  ],
  "resume_positions": [
    {
      "position_id": "pos1",
      "employer": "Synthetic Product Lab",
      "role": "разработчик или смежный специалист",
      "period": null,
      "project": null,
      "responsibilities": [],
      "skills": [
        "Python",
        "FastAPI",
        "Kafka",
        "PostgreSQL",
        "ClickHouse",
        "Kubernetes",
        "Grafana"
      ],
      "achievements": [],
      "evidence_ids": [
        "resume:003",
        "resume:004",
        "resume:005",
        "resume:006",
        "resume:007",
        "resume:008",
        "resume:009",
        "resume:010"
      ]
    }
  ],
  "resume_claims": [
    {
      "claim_id": "claim1",
      "claim_type": "experience",
      "subject": "6.5 лет опыта работы с Python backend",
      "evidence_ids": [
        "resume:005"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim2",
      "claim_type": "skill",
      "subject": "Опыт разработки на FastAPI для создания REST API",
      "evidence_ids": [
        "resume:005"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim3",
      "claim_type": "skill",
      "subject": "Опыт работы с Apache Kafka",
      "evidence_ids": [
        "resume:006"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim4",
      "claim_type": "skill",
      "subject": "Опыт работы с PostgreSQL",
      "evidence_ids": [
        "resume:007"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim5",
      "claim_type": "skill",
      "subject": "Опыт работы с ClickHouse",
      "evidence_ids": [
        "resume:008"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim6",
      "claim_type": "skill",
      "subject": "Опыт работы с Kubernetes",
      "evidence_ids": [
        "resume:009"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim7",
      "claim_type": "skill",
      "subject": "Опыт работы с Grafana для мониторинга",
      "evidence_ids": [
        "resume:010"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim8",
      "claim_type": "skill",
      "subject": "Сильный backend в event-driven архитектуре",
      "evidence_ids": [
        "resume:002"
      ],
      "verification_status": "supported"
    }
  ],
  "criterion_summaries": [
    {
      "criterion_id": "collaboration",
      "dimension": "soft_skills",
      "value": 0.75,
      "confidence": 0.8125,
      "observation_count": 4,
      "evidence_references": [
        "322b54dd-4ef1-40f2-9243-89338b1a4911:collaboration:0",
        "4a3890ad-89be-409a-85fe-44d0ce2b2a03:collaboration:0",
        "56013a9a-8b38-4bbd-bd8d-205424c6b1c4:collaboration:0",
        "9b95903c-e999-4521-9abc-52f5d7fcbb4e:collaboration:0"
      ]
    },
    {
      "criterion_id": "ownership",
      "dimension": "corporate_competencies",
      "value": 1.0,
      "confidence": 0.9,
      "observation_count": 4,
      "evidence_references": [
        "322b54dd-4ef1-40f2-9243-89338b1a4911:ownership:0",
        "4a3890ad-89be-409a-85fe-44d0ce2b2a03:ownership:0",
        "56013a9a-8b38-4bbd-bd8d-205424c6b1c4:ownership:0",
        "9b95903c-e999-4521-9abc-52f5d7fcbb4e:ownership:0"
      ]
    },
    {
      "criterion_id": "primary_vacancy_fit",
      "dimension": "vacancy_fit",
      "value": 0.5,
      "confidence": 0.8125,
      "observation_count": 4,
      "evidence_references": [
        "322b54dd-4ef1-40f2-9243-89338b1a4911:primary_vacancy_fit:0",
        "4a3890ad-89be-409a-85fe-44d0ce2b2a03:primary_vacancy_fit:0",
        "56013a9a-8b38-4bbd-bd8d-205424c6b1c4:primary_vacancy_fit:0",
        "9b95903c-e999-4521-9abc-52f5d7fcbb4e:primary_vacancy_fit:0"
      ]
    },
    {
      "criterion_id": "technical_depth",
      "dimension": "technical",
      "value": 1.0,
      "confidence": 0.9125,
      "observation_count": 4,
      "evidence_references": [
        "322b54dd-4ef1-40f2-9243-89338b1a4911:technical_depth:0",
        "4a3890ad-89be-409a-85fe-44d0ce2b2a03:technical_depth:0",
        "56013a9a-8b38-4bbd-bd8d-205424c6b1c4:technical_depth:0",
        "9b95903c-e999-4521-9abc-52f5d7fcbb4e:technical_depth:0"
      ]
    }
  ],
  "dimension_summaries": [
    {
      "dimension": "technical",
      "value": 1.0,
      "confidence": 0.9125,
      "assessed_criteria": 1,
      "applicable_criteria": 1,
      "coverage": 1.0
    },
    {
      "dimension": "soft_skills",
      "value": 0.75,
      "confidence": 0.8125,
      "assessed_criteria": 1,
      "applicable_criteria": 1,
      "coverage": 1.0
    },
    {
      "dimension": "corporate_competencies",
      "value": 1.0,
      "confidence": 0.9,
      "assessed_criteria": 1,
      "applicable_criteria": 1,
      "coverage": 1.0
    },
    {
      "dimension": "vacancy_fit",
      "value": 0.5,
      "confidence": 0.8125,
      "assessed_criteria": 1,
      "applicable_criteria": 1,
      "coverage": 1.0
    }
  ],
  "overall_readiness": 0.8125,
  "overall_confidence": 0.859375,
  "overall_coverage": 1.0,
  "professional_readiness": 0.9166666666666666,
  "professional_coverage": 1.0,
  "review_reason_codes": [],
  "strong_pool_eligible": true,
  "eligibility_reason_codes": [],
  "integrity_review_required": false,
  "compatibility_key": "f588f1fa9167e1ef322db08e56edeccf71535b7c8d94c074a6a5b427374be288",
  "is_hiring_decision": false
}

```


## Исходный результат `resume_relevance`

```json

{
  "schema_version": "session_agent_output_v2",
  "purpose": "resume_relevance",
  "positions": [
    {
      "position_id": "pos1",
      "employer": "Synthetic Product Lab",
      "role": "разработчик или смежный специалист",
      "period": null,
      "project": null,
      "responsibilities": [],
      "skills": [
        "Python",
        "FastAPI",
        "Kafka",
        "PostgreSQL",
        "ClickHouse",
        "Kubernetes",
        "Grafana"
      ],
      "achievements": [],
      "evidence_ids": [
        "resume:003",
        "resume:004",
        "resume:005",
        "resume:006",
        "resume:007",
        "resume:008",
        "resume:009",
        "resume:010"
      ]
    }
  ],
  "claims": [
    {
      "claim_id": "claim1",
      "claim_type": "experience",
      "subject": "6.5 лет опыта работы с Python backend",
      "evidence_ids": [
        "resume:005"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim2",
      "claim_type": "skill",
      "subject": "Опыт разработки на FastAPI для создания REST API",
      "evidence_ids": [
        "resume:005"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim3",
      "claim_type": "skill",
      "subject": "Опыт работы с Apache Kafka",
      "evidence_ids": [
        "resume:006"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim4",
      "claim_type": "skill",
      "subject": "Опыт работы с PostgreSQL",
      "evidence_ids": [
        "resume:007"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim5",
      "claim_type": "skill",
      "subject": "Опыт работы с ClickHouse",
      "evidence_ids": [
        "resume:008"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim6",
      "claim_type": "skill",
      "subject": "Опыт работы с Kubernetes",
      "evidence_ids": [
        "resume:009"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim7",
      "claim_type": "skill",
      "subject": "Опыт работы с Grafana для мониторинга",
      "evidence_ids": [
        "resume:010"
      ],
      "verification_status": "supported"
    },
    {
      "claim_id": "claim8",
      "claim_type": "skill",
      "subject": "Сильный backend в event-driven архитектуре",
      "evidence_ids": [
        "resume:002"
      ],
      "verification_status": "supported"
    }
  ],
  "experience_matches": [
    {
      "experience_label": "Опыт работы с Python от 5 лет",
      "evidence_ids": [
        "resume:005"
      ],
      "requirement_id": "vacancy:015",
      "requirement_origin": "vacancy",
      "relevance": 0.95,
      "confidence": 0.9,
      "explanation": "Соответствует требованию по опыту работы с Python (6.5 лет), подтверждено evidence resume:005.",
      "position_ids": [
        "pos1"
      ],
      "claim_ids": [
        "claim1"
      ]
    },
    {
      "experience_label": "Опыт разработки REST API с FastAPI",
      "evidence_ids": [
        "resume:005"
      ],
      "requirement_id": "vacancy:016",
      "requirement_origin": "vacancy",
      "relevance": 0.9,
      "confidence": 0.9,
      "explanation": "Кандидат имеет опыт разработки на FastAPI для REST API, подтверждено evidence resume:005.",
      "position_ids": [
        "pos1"
      ],
      "claim_ids": [
        "claim2"
      ]
    },
    {
      "experience_label": "Опыт работы с Apache Kafka",
      "evidence_ids": [
        "resume:006"
      ],
      "requirement_id": "vacancy:018",
      "requirement_origin": "vacancy",
      "relevance": 0.9,
      "confidence": 0.85,
      "explanation": "Опыт работы с Kafka на продакшн-уровне подтверждается evidence resume:006.",
      "position_ids": [
        "pos1"
      ],
      "claim_ids": [
        "claim3"
      ]
    },
    {
      "experience_label": "Опыт работы с PostgreSQL",
      "evidence_ids": [
        "resume:007"
      ],
      "requirement_id": "vacancy:019",
      "requirement_origin": "vacancy",
      "relevance": 0.85,
      "confidence": 0.85,
      "explanation": "Кандидат умеет работать с PostgreSQL, подтверждено evidence resume:007.",
      "position_ids": [
        "pos1"
      ],
      "claim_ids": [
        "claim4"
      ]
    },
    {
      "experience_label": "Опыт работы с ClickHouse",
      "evidence_ids": [
        "resume:008"
      ],
      "requirement_id": "vacancy:026",
      "requirement_origin": "vacancy",
      "relevance": 0.8,
      "confidence": 0.8,
      "explanation": "Опыт работы с ClickHouse подтверждается evidence resume:008.",
      "position_ids": [
        "pos1"
      ],
      "claim_ids": [
        "claim5"
      ]
    },
    {
      "experience_label": "Опыт работы с Kubernetes",
      "evidence_ids": [
        "resume:009"
      ],
      "requirement_id": "vacancy:024",
      "requirement_origin": "vacancy",
      "relevance": 0.8,
      "confidence": 0.8,
      "explanation": "Кандидат имеет опыт с Kubernetes для оркестрации контейнеров, подтверждено evidence resume:009.",
      "position_ids": [
        "pos1"
      ],
      "claim_ids": [
        "claim6"
      ]
    },
    {
      "experience_label": "Опыт настройки мониторинга и алертинга сервисов с Grafana",
      "evidence_ids": [
        "resume:010"
      ],
      "requirement_id": "vacancy:030",
      "requirement_origin": "vacancy",
      "relevance": 0.75,
      "confidence": 0.8,
      "explanation": "Опыт мониторинга сервисов с помощью Grafana подтверждается evidence resume:010.",
      "position_ids": [
        "pos1"
      ],
      "claim_ids": [
        "claim7"
      ]
    },
    {
      "experience_label": "Опыт работы в event-driven архитектуре",
      "evidence_ids": [
        "resume:002"
      ],
      "requirement_id": "vacancy:027",
      "requirement_origin": "vacancy",
      "relevance": 0.7,
      "confidence": 0.75,
      "explanation": "Профессиональный профиль кандидата указывает на сильный опыт event-driven backend, подтверждено evidence resume:002.",
      "position_ids": [
        "pos1"
      ],
      "claim_ids": [
        "claim8"
      ]
    }
  ],
  "gaps": [
    "Нет явного упоминания опыта работы с Django в резюме, хотя требуется для REST API.",
    "Не указаны навыки проектирования микросервисной архитектуры и опыт поддержки микросервисов напрямую.",
    "Отсутствуют сведения о продакшн опыте с producers/consumers Kafka, только общий опыт Kafka указан.",
    "Не заявлен опыт работы с ETL процессами (Extract, Transform, Load).",
    "Нет подтверждения опыта с Docker непосредственно, хотя есть Kubernetes.",
    "Нет упоминания об опыте проектирования API Gateway.",
    "Не указана работа с Prometheus или аналогами мониторинга кроме Grafana.",
    "Нет данных по Git и CI/CD практикам DevOps.",
    "Отсутствует информация по знанию gRPC, ELK Stack, Redis Cluster, Domain-Driven Design и performance tuning Python приложений."
  ]
}

```


## Исходный результат `integrity_check`

```json

{
  "schema_version": "session_agent_output_v2",
  "purpose": "integrity_check",
  "observations": [],
  "is_restriction": false
}

```


## Исходный результат `alternative_vacancy_match`

```json

{
  "schema_version": "session_agent_output_v2",
  "purpose": "alternative_vacancy_match",
  "target_vacancy_id": "b46e0484-e134-45de-94b2-db789770ea34",
  "candidate_grade": "middle",
  "target_grade": "middle",
  "compatibility_status": "compatible",
  "fit_value": 0.5,
  "matched_criteria": [
    "collaboration",
    "ownership",
    "primary_vacancy_fit",
    "technical_depth"
  ],
  "matched_terms": [
    "Python",
    "FastAPI",
    "PostgreSQL",
    "Kafka",
    "Kubernetes",
    "ClickHouse",
    "REST API",
    "code review",
    "event-driven architecture"
  ],
  "gaps": [
    "primary_vacancy_fit confidence moderate (0.5)",
    "collaboration not maximal (0.75)"
  ],
  "evidence_references": [
    "322b54dd-4ef1-40f2-9243-89338b1a4911:collaboration:0",
    "322b54dd-4ef1-40f2-9243-89338b1a4911:ownership:0",
    "322b54dd-4ef1-40f2-9243-89338b1a4911:primary_vacancy_fit:0",
    "322b54dd-4ef1-40f2-9243-89338b1a4911:technical_depth:0",
    "4a3890ad-89be-409a-85fe-44d0ce2b2a03:collaboration:0",
    "4a3890ad-89be-409a-85fe-44d0ce2b2a03:ownership:0",
    "4a3890ad-89be-409a-85fe-44d0ce2b2a03:primary_vacancy_fit:0",
    "4a3890ad-89be-409a-85fe-44d0ce2b2a03:technical_depth:0",
    "56013a9a-8b38-4bbd-bd8d-205424c6b1c4:collaboration:0",
    "56013a9a-8b38-4bbd-bd8d-205424c6b1c4:ownership:0",
    "56013a9a-8b38-4bbd-bd8d-205424c6b1c4:primary_vacancy_fit:0",
    "56013a9a-8b38-4bbd-bd8d-205424c6b1c4:technical_depth:0",
    "9b95903c-e999-4521-9abc-52f5d7fcbb4e:collaboration:0",
    "9b95903c-e999-4521-9abc-52f5d7fcbb4e:ownership:0",
    "9b95903c-e999-4521-9abc-52f5d7fcbb4e:primary_vacancy_fit:0",
    "9b95903c-e999-4521-9abc-52f5d7fcbb4e:technical_depth:0"
  ],
  "explanation": "The candidate is assessed at the 'middle' seniority level, matching the middle level required by the vacancy. Strong evidence supports technical depth with Python and related technologies (FastAPI, PostgreSQL, Kafka, Kubernetes, ClickHouse), collaboration, and ownership qualities, all relevant to the job description. The primary vacancy fit is moderate (0.5), reflecting some uncertainty or partial match in specific tasks, but no major gaps. Collaboration is good though not maximal. Overall, the candidate is compatible with the Middle Python API Developer vacancy, supported by multiple evidence references."
}

```
