# Полный сохранённый комплект PY-010

MAS-прогон 6 сентября не завершён. Секции явно разделяют оценку классификатора и фактически сохранённые этапы MAS.

## Полное резюме в MAS

СИНТЕТИЧЕСКОЕ РЕЗЮМЕ — не относится к реальному человеку.

Профессиональный профиль: Неподтверждённые заявления резюме.
Место работы: Synthetic Product Lab.
Роль: разработчик или смежный специалист согласно описанию опыта.
Опыт и стек: В резюме заявлены 5 лет Python, Kafka, Kubernetes и ClickHouse.


## Вакансия MAS

Middle + Python Developer
Уровень должности: Middle
Тип занятости: Полная занятость
Зарплата: Не указана
Опыт работы: от 3 лет коммерческой разработки
Регионы показа вакансии: Санкт-Петербург/ Челябинск

Обязанности:
● Разработка и поддержка высоконагруженных микросервисов;
● Интеграция с Kafka для обработки потоков данных;
● Проектирование Event Sourcing и CQRS паттернов;
● Разработка API для межсервисного взаимодействия;
● Настройка мониторинга и алертинга сервисов;
● Участие в Code review.

Требования:
● Опыт работы с Python от 5 лет;
● Django/FastAPI - опыт разработки REST API;
● Микросервисная архитектура - опыт проектирования и поддержки;
● Apache Kafka - продакшн опыт работы с producers/consumers;
● PostgreSQL - проектирование схем, оптимизация запросов;
● ETL процессы - Extract, Transform, Load данных;
● Docker/Kubernetes - контейнеризация и оркестрация;
● Базы данных: PostgreSQL, ClickHouse;
● Event-driven архитектура - паттерны работы с событиями;
● API Gateway - опыт интеграции через шлюзы;
● Мониторинг: Prometheus, Grafana или аналоги;
● Git, CI/CD - DevOps практики.

Будет плюсом:
● Знание gRPC для межсервисного взаимодействия;
● Опыт с ELK Stack (Elasticsearch, Logstash, Kibana);
● Redis Cluster для высокодоступного кэширования;
● Знание Domain-Driven Design (DDD);
● Опыт performance tuning Python приложений.

Условия:
● Удаленная работа, гибкое начало и конец рабочего дня при синхронизации с командой.
● Индивидуальный план развития с возможностью освоения новых технологий.
● Насыщенная корпоративная жизнь.
● Оплата профильных конференций и профессиональной литературы.
● Доступ к курсам GIGASCHOOL.


# PY-010: Неподтверждённые заявления резюме

Данные synthetic. Это отдельная проверка answer-assessment v2, не полный MAS-конвейер.

## Резюме в проверке классификатора

В резюме заявлены 5 лет Python, Kafka, Kubernetes и ClickHouse.

## Вопрос

Опишите релевантный вакансии production-опыт: ваш личный вклад, архитектуру Python-сервиса, надёжность обработки сообщений, работу с PostgreSQL, контейнеризацию и наблюдаемость, а также измеримый результат; если опыта с обязательной технологией нет, скажите об этом прямо?

## Полный ответ

В проекте действительно упоминались Kafka, Kubernetes и ClickHouse, но их настраивали другие участники команды. Я менял несколько Python-обработчиков, однако не помню, как коммитился offset, обеспечивалась идемпотентность или измерялась нагрузка. Не могу точно отделить свои решения от командных. PostgreSQL-запросы правил, но планы и результаты замеров сейчас привести не готов.

## Оценка для рекрутера

Тестовый прогноз: **следует уточнить**. Эталон synthetic-датасета: следует уточнить. Решение человека не зафиксировано.

Основание эталонной разметки: Между заявленным стеком и доказательствами ответа остаётся существенная неопределённость.

Оценка AI по ответу; `value` — исходное значение, `confidence` — уверенность модели.


**Технические компетенции** (`technical_depth`)

Метка: `weak`; значение: `-0.5`; уверенность: `0.7`.

The candidate mentions involvement in Python handlers and some PostgreSQL queries but is unsure about key technical details like offset committing, idempotency, and performance measurements, indicating limited personal contribution and understanding of production robustness.


Evidence: `answer:48a8513c-f317-5a12-aa0d-c1aa98116b01:001` (counter).


> В проекте действительно упоминались Kafka, Kubernetes и ClickHouse, но их настраивали другие участники команды. Я менял несколько Python-обработчиков, однако не помню, как коммитился offset, обеспечивалась идемпотентность или измерялась нагрузка. Не могу точно отделить свои решения от командных. PostgreSQL-запросы правил, но планы и результаты замеров сейчас привести не готов.


**Соответствие вакансии** (`primary_vacancy_fit`)

Метка: `weak`; значение: `-0.5`; уверенность: `0.6`.

The answer acknowledges technologies like Kafka, Kubernetes, and ClickHouse but specifies that others configured them, and does not confirm direct production experience with mandatory technologies such as Django/FastAPI, high-load microservices, observability, or CI/CD, leading to weak confidence in vacancy fit.


Evidence: `answer:48a8513c-f317-5a12-aa0d-c1aa98116b01:001` (counter).


> В проекте действительно упоминались Kafka, Kubernetes и ClickHouse, но их настраивали другие участники команды. Я менял несколько Python-обработчиков, однако не помню, как коммитился offset, обеспечивалась идемпотентность или измерялась нагрузка. Не могу точно отделить свои решения от командных. PostgreSQL-запросы правил, но планы и результаты замеров сейчас привести не готов.


Назначение `follow_up` из исходной оценки:

```json

[
  {
    "trigger": "missing_detail",
    "prompt": "Можете ли подробно описать ваш вклад в архитектуру Python-сервиса, в частности, как обеспечивалась надёжность обработки сообщений и какие приёмы использовались для измерения и оптимизации производительности?",
    "reason": "Для уточнения технической глубины и подтверждения личного вклада в ключевые механизмы решения.",
    "criterion_ids": [
      "technical_depth"
    ],
    "requirement_ids": [
      "req-kafka",
      "req-observability"
    ],
    "resume_claim_ids": []
  }
]

```

## Полный результат классификатора

```json

{
  "candidate_id": "PY-010",
  "profile": "Неподтверждённые заявления резюме",
  "target": "следует уточнить",
  "target_reason": "Между заявленным стеком и доказательствами ответа остаётся существенная неопределённость.",
  "prediction": "следует уточнить",
  "correct": true,
  "technical": {
    "label": "weak",
    "value": -0.5,
    "confidence": 0.7,
    "explanation": "The candidate mentions involvement in Python handlers and some PostgreSQL queries but is unsure about key technical details like offset committing, idempotency, and performance measurements, indicating limited personal contribution and understanding of production robustness."
  },
  "vacancy_fit": {
    "label": "weak",
    "value": -0.5,
    "confidence": 0.6,
    "explanation": "The answer acknowledges technologies like Kafka, Kubernetes, and ClickHouse but specifies that others configured them, and does not confirm direct production experience with mandatory technologies such as Django/FastAPI, high-load microservices, observability, or CI/CD, leading to weak confidence in vacancy fit."
  },
  "follow_up_count": 1,
  "follow_up": [
    "Можете ли подробно описать ваш вклад в архитектуру Python-сервиса, в частности, как обеспечивалась надёжность обработки сообщений и какие приёмы использовались для измерения и оптимизации производительности?"
  ],
  "attempts": 1,
  "resume": "В резюме заявлены 5 лет Python, Kafka, Kubernetes и ClickHouse.",
  "answer": "В проекте действительно упоминались Kafka, Kubernetes и ClickHouse, но их настраивали другие участники команды. Я менял несколько Python-обработчиков, однако не помню, как коммитился offset, обеспечивалась идемпотентность или измерялась нагрузка. Не могу точно отделить свои решения от командных. PostgreSQL-запросы правил, но планы и результаты замеров сейчас привести не готов.",
  "raw_assessment": {
    "schema_version": "session_agent_output_v2",
    "purpose": "answer_assessment",
    "response_id": "48a8513c-f317-5a12-aa0d-c1aa98116b01",
    "question_id": "cbdae577-cae3-5647-9900-f56fddf2f4c8",
    "observations": [
      {
        "criterion_id": "technical_depth",
        "dimension": "technical",
        "label": "weak",
        "value": -0.5,
        "confidence": 0.7,
        "explanation": "The candidate mentions involvement in Python handlers and some PostgreSQL queries but is unsure about key technical details like offset committing, idempotency, and performance measurements, indicating limited personal contribution and understanding of production robustness.",
        "evidence": [
          {
            "kind": "counter",
            "evidence_id": "answer:48a8513c-f317-5a12-aa0d-c1aa98116b01:001"
          }
        ]
      },
      {
        "criterion_id": "primary_vacancy_fit",
        "dimension": "vacancy_fit",
        "label": "weak",
        "value": -0.5,
        "confidence": 0.6,
        "explanation": "The answer acknowledges technologies like Kafka, Kubernetes, and ClickHouse but specifies that others configured them, and does not confirm direct production experience with mandatory technologies such as Django/FastAPI, high-load microservices, observability, or CI/CD, leading to weak confidence in vacancy fit.",
        "evidence": [
          {
            "kind": "counter",
            "evidence_id": "answer:48a8513c-f317-5a12-aa0d-c1aa98116b01:001"
          }
        ]
      }
    ],
    "follow_up": [
      {
        "trigger": "missing_detail",
        "prompt": "Можете ли подробно описать ваш вклад в архитектуру Python-сервиса, в частности, как обеспечивалась надёжность обработки сообщений и какие приёмы использовались для измерения и оптимизации производительности?",
        "reason": "Для уточнения технической глубины и подтверждения личного вклада в ключевые механизмы решения.",
        "criterion_ids": [
          "technical_depth"
        ],
        "requirement_ids": [
          "req-kafka",
          "req-observability"
        ],
        "resume_claim_ids": []
      }
    ],
    "live_coding": null
  }
}

```

# Вопросы, ответы и оценки



Ответы synthetic: это тестовые данные, не интервью реального кандидата.


В этом MAS-прогоне ответы не были сохранены. Результаты отдельного классификатора находятся в соседнем файле.

# Оценка для рекрутера

Оценка AI и решение человека разделены. Решение рекрутера и нанимающего менеджера в исходных материалах не зафиксировано.

Итоговый профиль MAS отсутствует: конвейер не дошёл до успешной финализации. Доступные оценки отдельных ответов сохранены отдельно.

# Фидбэк пользователю

Готовый фидбэк отсутствует: успешный артефакт candidate_feedback в этом прогоне не создан.
