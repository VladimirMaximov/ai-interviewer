# PY-006: Frontend/PHP профиль без Python production

Данные synthetic. Это отдельная проверка answer-assessment v2, не полный MAS-конвейер.

## Резюме в проверке классификатора

6 лет frontend и PHP; Python только на учебном курсе.

## Вопрос

Опишите релевантный вакансии production-опыт: ваш личный вклад, архитектуру Python-сервиса, надёжность обработки сообщений, работу с PostgreSQL, контейнеризацию и наблюдаемость, а также измеримый результат; если опыта с обязательной технологией нет, скажите об этом прямо?

## Полный ответ

Мой коммерческий опыт — frontend и PHP, Python изучал несколько месяцев на курсе. Production-сервисов на Django или FastAPI не делал, с Kafka и Kubernetes не работал. Для очереди я бы удалял сообщение сразу после чтения и при ошибке просто терял его, чтобы очередь не блокировалась. PostgreSQL использовал только для простых CRUD-запросов, метрик нагрузки у меня нет.

## Оценка для рекрутера

Тестовый прогноз: **не подходит**. Эталон synthetic-датасета: не подходит. Решение человека не зафиксировано.

Основание эталонной разметки: Профиль не соответствует роли, а техническое решение небезопасно.

Оценка AI по ответу; `value` — исходное значение, `confidence` — уверенность модели.


**Технические компетенции** (`technical_depth`)

Метка: `weak`; значение: `-0.5`; уверенность: `0.9`.

The candidate has no commercial production experience with Django, FastAPI, Kafka, or Kubernetes, and only used PostgreSQL for simple CRUD without workload metrics. The queue handling plan described would lose messages on error, which is a material downside, indicating a misunderstanding of reliable message processing.


Evidence: `answer:81cb10db-b41c-5e64-8804-2ec9a65cee2c:001` (counter).


> Мой коммерческий опыт — frontend и PHP, Python изучал несколько месяцев на курсе. Production-сервисов на Django или FastAPI не делал, с Kafka и Kubernetes не работал. Для очереди я бы удалял сообщение сразу после чтения и при ошибке просто терял его, чтобы очередь не блокировалась. PostgreSQL использовал только для простых CRUD-запросов, метрик нагрузки у меня нет.


**Соответствие вакансии** (`primary_vacancy_fit`)

Метка: `weak`; значение: `-0.5`; уверенность: `0.85`.

The candidate explicitly states lack of experience with required technologies (5+ years Python, Django/FastAPI, Kafka, Kubernetes, advanced PostgreSQL) and does not demonstrate any relevant production experience for the vacancy requirements.


Evidence: `answer:81cb10db-b41c-5e64-8804-2ec9a65cee2c:001` (counter).


> Мой коммерческий опыт — frontend и PHP, Python изучал несколько месяцев на курсе. Production-сервисов на Django или FastAPI не делал, с Kafka и Kubernetes не работал. Для очереди я бы удалял сообщение сразу после чтения и при ошибке просто терял его, чтобы очередь не блокировалась. PostgreSQL использовал только для простых CRUD-запросов, метрик нагрузки у меня нет.


Назначение `follow_up` из исходной оценки:

```json

[
  {
    "trigger": "missing_detail",
    "prompt": "Можете ли вы подробно описать ваш опыт работы с PostgreSQL, включая схемы данных и оптимизацию запросов?",
    "reason": "Недостаточно информации по работе с PostgreSQL для оценки технической глубины.",
    "criterion_ids": [
      "technical_depth"
    ],
    "requirement_ids": [
      "req-postgresql"
    ],
    "resume_claim_ids": []
  }
]

```

## Полный результат классификатора

```json

{
  "candidate_id": "PY-006",
  "profile": "Frontend/PHP профиль без Python production",
  "target": "не подходит",
  "target_reason": "Профиль не соответствует роли, а техническое решение небезопасно.",
  "prediction": "не подходит",
  "correct": true,
  "technical": {
    "label": "weak",
    "value": -0.5,
    "confidence": 0.9,
    "explanation": "The candidate has no commercial production experience with Django, FastAPI, Kafka, or Kubernetes, and only used PostgreSQL for simple CRUD without workload metrics. The queue handling plan described would lose messages on error, which is a material downside, indicating a misunderstanding of reliable message processing."
  },
  "vacancy_fit": {
    "label": "weak",
    "value": -0.5,
    "confidence": 0.85,
    "explanation": "The candidate explicitly states lack of experience with required technologies (5+ years Python, Django/FastAPI, Kafka, Kubernetes, advanced PostgreSQL) and does not demonstrate any relevant production experience for the vacancy requirements."
  },
  "follow_up_count": 1,
  "follow_up": [
    "Можете ли вы подробно описать ваш опыт работы с PostgreSQL, включая схемы данных и оптимизацию запросов?"
  ],
  "attempts": 1,
  "resume": "6 лет frontend и PHP; Python только на учебном курсе.",
  "answer": "Мой коммерческий опыт — frontend и PHP, Python изучал несколько месяцев на курсе. Production-сервисов на Django или FastAPI не делал, с Kafka и Kubernetes не работал. Для очереди я бы удалял сообщение сразу после чтения и при ошибке просто терял его, чтобы очередь не блокировалась. PostgreSQL использовал только для простых CRUD-запросов, метрик нагрузки у меня нет.",
  "raw_assessment": {
    "schema_version": "session_agent_output_v2",
    "purpose": "answer_assessment",
    "response_id": "81cb10db-b41c-5e64-8804-2ec9a65cee2c",
    "question_id": "cbdae577-cae3-5647-9900-f56fddf2f4c8",
    "observations": [
      {
        "criterion_id": "technical_depth",
        "dimension": "technical",
        "label": "weak",
        "value": -0.5,
        "confidence": 0.9,
        "explanation": "The candidate has no commercial production experience with Django, FastAPI, Kafka, or Kubernetes, and only used PostgreSQL for simple CRUD without workload metrics. The queue handling plan described would lose messages on error, which is a material downside, indicating a misunderstanding of reliable message processing.",
        "evidence": [
          {
            "kind": "counter",
            "evidence_id": "answer:81cb10db-b41c-5e64-8804-2ec9a65cee2c:001"
          }
        ]
      },
      {
        "criterion_id": "primary_vacancy_fit",
        "dimension": "vacancy_fit",
        "label": "weak",
        "value": -0.5,
        "confidence": 0.85,
        "explanation": "The candidate explicitly states lack of experience with required technologies (5+ years Python, Django/FastAPI, Kafka, Kubernetes, advanced PostgreSQL) and does not demonstrate any relevant production experience for the vacancy requirements.",
        "evidence": [
          {
            "kind": "counter",
            "evidence_id": "answer:81cb10db-b41c-5e64-8804-2ec9a65cee2c:001"
          }
        ]
      }
    ],
    "follow_up": [
      {
        "trigger": "missing_detail",
        "prompt": "Можете ли вы подробно описать ваш опыт работы с PostgreSQL, включая схемы данных и оптимизацию запросов?",
        "reason": "Недостаточно информации по работе с PostgreSQL для оценки технической глубины.",
        "criterion_ids": [
          "technical_depth"
        ],
        "requirement_ids": [
          "req-postgresql"
        ],
        "resume_claim_ids": []
      }
    ],
    "live_coding": null
  }
}

```
