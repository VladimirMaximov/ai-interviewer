# PY-009: Смежный RabbitMQ/Docker опыт

Данные synthetic. Это отдельная проверка answer-assessment v2, не полный MAS-конвейер.

## Резюме в проверке классификатора

4 года Python/FastAPI, RabbitMQ и Docker; без Kafka и Kubernetes.

## Вопрос

Опишите релевантный вакансии production-опыт: ваш личный вклад, архитектуру Python-сервиса, надёжность обработки сообщений, работу с PostgreSQL, контейнеризацию и наблюдаемость, а также измеримый результат; если опыта с обязательной технологией нет, скажите об этом прямо?

## Полный ответ

Четыре года пишу FastAPI-сервисы на Python. В production использовал RabbitMQ: ack после обработки, retry, DLQ и идемпотентность. PostgreSQL оптимизировал индексами и EXPLAIN ANALYZE, Docker и GitLab CI настраивал лично. С Kafka, Kubernetes, ClickHouse и полноценным ETL пока не работал. Не знаю, являются ли эти технологии жёстким стоп-фактором; готов разобрать архитектуру RabbitMQ и план перехода подробнее.

## Оценка для рекрутера

Тестовый прогноз: **следует уточнить**. Эталон synthetic-датасета: следует уточнить. Решение человека не зафиксировано.

Основание эталонной разметки: Есть сильная переносимая база, но обязательность Kafka/Kubernetes требует решения человека.

Оценка AI по ответу; `value` — исходное значение, `confidence` — уверенность модели.


**Технические компетенции** (`technical_depth`)

Метка: `supported`; значение: `0.5`; уверенность: `0.8`.

Candidate describes 4 years developing FastAPI services in Python, mentions RabbitMQ usage in production with acknowledgments, retries, DLQ, and idempotency, and PostgreSQL optimization with indexes and EXPLAIN ANALYZE. Also configures Docker and GitLab CI personally. No experience with Kafka, Kubernetes, or ETL, but the detailed RabbitMQ usage and PostgreSQL optimizations represent a practical production experience showing technical depth.


Evidence: `answer:ada6869a-36c3-51b8-8c3e-8f652477f941:001` (supporting).


> Четыре года пишу FastAPI-сервисы на Python. В production использовал RabbitMQ: ack после обработки, retry, DLQ и идемпотентность. PostgreSQL оптимизировал индексами и EXPLAIN ANALYZE, Docker и GitLab CI настраивал лично. С Kafka, Kubernetes, ClickHouse и полноценным ETL пока не работал. Не знаю, являются ли эти технологии жёстким стоп-фактором; готов разобрать архитектуру RabbitMQ и план перехода подробнее.


**Соответствие вакансии** (`primary_vacancy_fit`)

Метка: `weak`; значение: `-0.5`; уверенность: `0.7`.

Candidate meets several requirements: 4 years Python with FastAPI, RabbitMQ in production, PostgreSQL optimization, Docker and GitLab CI. However, lacks experience with mandatory vacancy technologies such as Kafka, Kubernetes, ETL, ClickHouse, and observability tools like Prometheus/Grafana. Hence partial fit with important missing requirements for the role.


Evidence: `answer:ada6869a-36c3-51b8-8c3e-8f652477f941:001` (counter).


> Четыре года пишу FastAPI-сервисы на Python. В production использовал RabbitMQ: ack после обработки, retry, DLQ и идемпотентность. PostgreSQL оптимизировал индексами и EXPLAIN ANALYZE, Docker и GitLab CI настраивал лично. С Kafka, Kubernetes, ClickHouse и полноценным ETL пока не работал. Не знаю, являются ли эти технологии жёстким стоп-фактором; готов разобрать архитектуру RabbitMQ и план перехода подробнее.


Назначение `follow_up` из исходной оценки:

```json

[
  {
    "trigger": "missing_detail",
    "prompt": "Можете ли вы подробнее описать ваш опыт работы с RabbitMQ в production, особенно какие архитектурные решения и механизмы надёжности применялись?",
    "reason": "Техническая глубина требует больше деталей по реальному производственному опыту с RabbitMQ для подтверждения уровня владения.",
    "criterion_ids": [
      "technical_depth"
    ],
    "requirement_ids": [
      "req-microservices"
    ],
    "resume_claim_ids": []
  }
]

```

## Полный результат классификатора

```json

{
  "candidate_id": "PY-009",
  "profile": "Смежный RabbitMQ/Docker опыт",
  "target": "следует уточнить",
  "target_reason": "Есть сильная переносимая база, но обязательность Kafka/Kubernetes требует решения человека.",
  "prediction": "следует уточнить",
  "correct": true,
  "technical": {
    "label": "supported",
    "value": 0.5,
    "confidence": 0.8,
    "explanation": "Candidate describes 4 years developing FastAPI services in Python, mentions RabbitMQ usage in production with acknowledgments, retries, DLQ, and idempotency, and PostgreSQL optimization with indexes and EXPLAIN ANALYZE. Also configures Docker and GitLab CI personally. No experience with Kafka, Kubernetes, or ETL, but the detailed RabbitMQ usage and PostgreSQL optimizations represent a practical production experience showing technical depth."
  },
  "vacancy_fit": {
    "label": "weak",
    "value": -0.5,
    "confidence": 0.7,
    "explanation": "Candidate meets several requirements: 4 years Python with FastAPI, RabbitMQ in production, PostgreSQL optimization, Docker and GitLab CI. However, lacks experience with mandatory vacancy technologies such as Kafka, Kubernetes, ETL, ClickHouse, and observability tools like Prometheus/Grafana. Hence partial fit with important missing requirements for the role."
  },
  "follow_up_count": 1,
  "follow_up": [
    "Можете ли вы подробнее описать ваш опыт работы с RabbitMQ в production, особенно какие архитектурные решения и механизмы надёжности применялись?"
  ],
  "attempts": 1,
  "resume": "4 года Python/FastAPI, RabbitMQ и Docker; без Kafka и Kubernetes.",
  "answer": "Четыре года пишу FastAPI-сервисы на Python. В production использовал RabbitMQ: ack после обработки, retry, DLQ и идемпотентность. PostgreSQL оптимизировал индексами и EXPLAIN ANALYZE, Docker и GitLab CI настраивал лично. С Kafka, Kubernetes, ClickHouse и полноценным ETL пока не работал. Не знаю, являются ли эти технологии жёстким стоп-фактором; готов разобрать архитектуру RabbitMQ и план перехода подробнее.",
  "raw_assessment": {
    "schema_version": "session_agent_output_v2",
    "purpose": "answer_assessment",
    "response_id": "ada6869a-36c3-51b8-8c3e-8f652477f941",
    "question_id": "cbdae577-cae3-5647-9900-f56fddf2f4c8",
    "observations": [
      {
        "criterion_id": "technical_depth",
        "dimension": "technical",
        "label": "supported",
        "value": 0.5,
        "confidence": 0.8,
        "explanation": "Candidate describes 4 years developing FastAPI services in Python, mentions RabbitMQ usage in production with acknowledgments, retries, DLQ, and idempotency, and PostgreSQL optimization with indexes and EXPLAIN ANALYZE. Also configures Docker and GitLab CI personally. No experience with Kafka, Kubernetes, or ETL, but the detailed RabbitMQ usage and PostgreSQL optimizations represent a practical production experience showing technical depth.",
        "evidence": [
          {
            "kind": "supporting",
            "evidence_id": "answer:ada6869a-36c3-51b8-8c3e-8f652477f941:001"
          }
        ]
      },
      {
        "criterion_id": "primary_vacancy_fit",
        "dimension": "vacancy_fit",
        "label": "weak",
        "value": -0.5,
        "confidence": 0.7,
        "explanation": "Candidate meets several requirements: 4 years Python with FastAPI, RabbitMQ in production, PostgreSQL optimization, Docker and GitLab CI. However, lacks experience with mandatory vacancy technologies such as Kafka, Kubernetes, ETL, ClickHouse, and observability tools like Prometheus/Grafana. Hence partial fit with important missing requirements for the role.",
        "evidence": [
          {
            "kind": "counter",
            "evidence_id": "answer:ada6869a-36c3-51b8-8c3e-8f652477f941:001"
          }
        ]
      }
    ],
    "follow_up": [
      {
        "trigger": "missing_detail",
        "prompt": "Можете ли вы подробнее описать ваш опыт работы с RabbitMQ в production, особенно какие архитектурные решения и механизмы надёжности применялись?",
        "reason": "Техническая глубина требует больше деталей по реальному производственному опыту с RabbitMQ для подтверждения уровня владения.",
        "criterion_ids": [
          "technical_depth"
        ],
        "requirement_ids": [
          "req-microservices"
        ],
        "resume_claim_ids": []
      }
    ],
    "live_coding": null
  }
}

```
