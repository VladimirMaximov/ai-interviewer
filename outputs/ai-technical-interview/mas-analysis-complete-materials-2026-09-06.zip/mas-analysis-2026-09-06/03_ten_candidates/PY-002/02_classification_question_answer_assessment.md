# PY-002: Django/FastAPI platform engineer

Данные synthetic. Это отдельная проверка answer-assessment v2, не полный MAS-конвейер.

## Резюме в проверке классификатора

5 лет 8 месяцев Python: Django, FastAPI, Kafka, PostgreSQL, Kubernetes, CI/CD.

## Вопрос

Опишите релевантный вакансии production-опыт: ваш личный вклад, архитектуру Python-сервиса, надёжность обработки сообщений, работу с PostgreSQL, контейнеризацию и наблюдаемость, а также измеримый результат; если опыта с обязательной технологией нет, скажите об этом прямо?

## Полный ответ

Пять лет и восемь месяцев разрабатываю на Python. В последнем проекте лично вёл Django API и два FastAPI-микросервиса. Для Kafka настроил manual commit после успешной транзакции, idempotency key и dead-letter topic. Проектировал PostgreSQL схемы, использовал COPY для загрузок и ETL в ClickHouse. Собирал Docker-образы, правил Helm values и deployment в Kubernetes, поддерживал GitLab CI. Дашборды Prometheus/Grafana показали снижение consumer lag с 90 до 8 секунд.

## Оценка для рекрутера

Тестовый прогноз: **подходит**. Эталон synthetic-датасета: подходит. Решение человека не зафиксировано.

Основание эталонной разметки: Опыт превышает порог и прямо покрывает backend, данные и эксплуатацию.

Оценка AI по ответу; `value` — исходное значение, `confidence` — уверенность модели.


**Технические компетенции** (`technical_depth`)

Метка: `strong`; значение: `1.0`; уверенность: `0.9`.

The candidate provides a detailed, technically correct description of their production experience with Python, including concrete implementation details such as managing Django and FastAPI microservices, Kafka manual commit with idempotency and dead-letter topics, PostgreSQL schema design and COPY for efficient data loading, Docker image building, Helm configuration for Kubernetes deployment, GitLab CI support, and measurable improvement in consumer lag observed via Prometheus/Grafana. This level of detail and technical correctness supports a strong rating for technical depth and production solution quality.


Evidence: `answer:7ea8a46e-a195-5c2b-b003-ba334665b245:001` (supporting).


> Пять лет и восемь месяцев разрабатываю на Python. В последнем проекте лично вёл Django API и два FastAPI-микросервиса. Для Kafka настроил manual commit после успешной транзакции, idempotency key и dead-letter topic. Проектировал PostgreSQL схемы, использовал COPY для загрузок и ETL в ClickHouse. Собирал Docker-образы, правил Helm values и deployment в Kubernetes, поддерживал GitLab CI. Дашборды Prometheus/Grafana показали снижение consumer lag с 90 до 8 секунд.


**Соответствие вакансии** (`primary_vacancy_fit`)

Метка: `strong`; значение: `1.0`; уверенность: `0.85`.

The answer explicitly confirms 5+ years of Python experience and mentions Django and FastAPI REST APIs, handling high-load microservices, production Kafka producers/consumers, PostgreSQL schemas, ETL and ClickHouse usage, Docker and Kubernetes, Prometheus/Grafana monitoring, and GitLab CI/CD. This directly matches all listed mandatory vacancy requirements, showing excellent fit for the role.


Evidence: `answer:7ea8a46e-a195-5c2b-b003-ba334665b245:001` (supporting).


> Пять лет и восемь месяцев разрабатываю на Python. В последнем проекте лично вёл Django API и два FastAPI-микросервиса. Для Kafka настроил manual commit после успешной транзакции, idempotency key и dead-letter topic. Проектировал PostgreSQL схемы, использовал COPY для загрузок и ETL в ClickHouse. Собирал Docker-образы, правил Helm values и deployment в Kubernetes, поддерживал GitLab CI. Дашборды Prometheus/Grafana показали снижение consumer lag с 90 до 8 секунд.

## Полный результат классификатора

```json

{
  "candidate_id": "PY-002",
  "profile": "Django/FastAPI platform engineer",
  "target": "подходит",
  "target_reason": "Опыт превышает порог и прямо покрывает backend, данные и эксплуатацию.",
  "prediction": "подходит",
  "correct": true,
  "technical": {
    "label": "strong",
    "value": 1.0,
    "confidence": 0.9,
    "explanation": "The candidate provides a detailed, technically correct description of their production experience with Python, including concrete implementation details such as managing Django and FastAPI microservices, Kafka manual commit with idempotency and dead-letter topics, PostgreSQL schema design and COPY for efficient data loading, Docker image building, Helm configuration for Kubernetes deployment, GitLab CI support, and measurable improvement in consumer lag observed via Prometheus/Grafana. This level of detail and technical correctness supports a strong rating for technical depth and production solution quality."
  },
  "vacancy_fit": {
    "label": "strong",
    "value": 1.0,
    "confidence": 0.85,
    "explanation": "The answer explicitly confirms 5+ years of Python experience and mentions Django and FastAPI REST APIs, handling high-load microservices, production Kafka producers/consumers, PostgreSQL schemas, ETL and ClickHouse usage, Docker and Kubernetes, Prometheus/Grafana monitoring, and GitLab CI/CD. This directly matches all listed mandatory vacancy requirements, showing excellent fit for the role."
  },
  "follow_up_count": 0,
  "follow_up": [],
  "attempts": 1,
  "resume": "5 лет 8 месяцев Python: Django, FastAPI, Kafka, PostgreSQL, Kubernetes, CI/CD.",
  "answer": "Пять лет и восемь месяцев разрабатываю на Python. В последнем проекте лично вёл Django API и два FastAPI-микросервиса. Для Kafka настроил manual commit после успешной транзакции, idempotency key и dead-letter topic. Проектировал PostgreSQL схемы, использовал COPY для загрузок и ETL в ClickHouse. Собирал Docker-образы, правил Helm values и deployment в Kubernetes, поддерживал GitLab CI. Дашборды Prometheus/Grafana показали снижение consumer lag с 90 до 8 секунд.",
  "raw_assessment": {
    "schema_version": "session_agent_output_v2",
    "purpose": "answer_assessment",
    "response_id": "7ea8a46e-a195-5c2b-b003-ba334665b245",
    "question_id": "cbdae577-cae3-5647-9900-f56fddf2f4c8",
    "observations": [
      {
        "criterion_id": "technical_depth",
        "dimension": "technical",
        "label": "strong",
        "value": 1.0,
        "confidence": 0.9,
        "explanation": "The candidate provides a detailed, technically correct description of their production experience with Python, including concrete implementation details such as managing Django and FastAPI microservices, Kafka manual commit with idempotency and dead-letter topics, PostgreSQL schema design and COPY for efficient data loading, Docker image building, Helm configuration for Kubernetes deployment, GitLab CI support, and measurable improvement in consumer lag observed via Prometheus/Grafana. This level of detail and technical correctness supports a strong rating for technical depth and production solution quality.",
        "evidence": [
          {
            "kind": "supporting",
            "evidence_id": "answer:7ea8a46e-a195-5c2b-b003-ba334665b245:001"
          }
        ]
      },
      {
        "criterion_id": "primary_vacancy_fit",
        "dimension": "vacancy_fit",
        "label": "strong",
        "value": 1.0,
        "confidence": 0.85,
        "explanation": "The answer explicitly confirms 5+ years of Python experience and mentions Django and FastAPI REST APIs, handling high-load microservices, production Kafka producers/consumers, PostgreSQL schemas, ETL and ClickHouse usage, Docker and Kubernetes, Prometheus/Grafana monitoring, and GitLab CI/CD. This directly matches all listed mandatory vacancy requirements, showing excellent fit for the role.",
        "evidence": [
          {
            "kind": "supporting",
            "evidence_id": "answer:7ea8a46e-a195-5c2b-b003-ba334665b245:001"
          }
        ]
      }
    ],
    "follow_up": null,
    "live_coding": null
  }
}

```
