# PY-008: Сильные заявления без деталей

Данные synthetic. Это отдельная проверка answer-assessment v2, не полный MAS-конвейер.

## Резюме в проверке классификатора

Заявлены 6 лет Python, Kafka, Kubernetes, PostgreSQL и FastAPI.

## Вопрос

Опишите релевантный вакансии production-опыт: ваш личный вклад, архитектуру Python-сервиса, надёжность обработки сообщений, работу с PostgreSQL, контейнеризацию и наблюдаемость, а также измеримый результат; если опыта с обязательной технологией нет, скажите об этом прямо?

## Полный ответ

Работал с Python, FastAPI, Kafka, PostgreSQL и Kubernetes. Проект был большой и нагруженный, всё работало хорошо. Архитектуру и надёжность настраивала команда, свой личный вклад и конкретные решения сейчас описать не могу. Метрики не помню.

## Оценка для рекрутера

Тестовый прогноз: **следует уточнить**. Эталон synthetic-датасета: следует уточнить. Решение человека не зафиксировано.

Основание эталонной разметки: Резюме выглядит релевантно, но ответ не позволяет подтвердить личный вклад.

Оценка AI по ответу; `value` — исходное значение, `confidence` — уверенность модели.


**Технические компетенции** (`technical_depth`)

Метка: `weak`; значение: `-0.5`; уверенность: `0.8`.

The candidate lists relevant technologies (Python, FastAPI, Kafka, PostgreSQL, Kubernetes) and notes the project was large and high-load, but does not describe specific personal contributions, architectural decisions, or reliability improvements. No concrete example of production solution design or trade-offs, nor measurable results were provided, limiting confidence in technical depth.


Evidence: `answer:681ce2c2-32ca-52af-afda-f6f6d3e7af06:001` (counter).


> Работал с Python, FastAPI, Kafka, PostgreSQL и Kubernetes. Проект был большой и нагруженный, всё работало хорошо. Архитектуру и надёжность настраивала команда, свой личный вклад и конкретные решения сейчас описать не могу. Метрики не помню.


**Соответствие вакансии** (`primary_vacancy_fit`)

Метка: `weak`; значение: `-0.5`; уверенность: `0.75`.

The answer mentions technologies required by the vacancy (Python, FastAPI, Kafka, PostgreSQL, Kubernetes), indicating some relevance. However, lack of details about own contributions, handling of mandatory topics like schema design, Kafka production-grade usage, observability, and measurable impact reduce clarity on full fit to mandatory requirements.


Evidence: `answer:681ce2c2-32ca-52af-afda-f6f6d3e7af06:001` (counter).


> Работал с Python, FastAPI, Kafka, PostgreSQL и Kubernetes. Проект был большой и нагруженный, всё работало хорошо. Архитектуру и надёжность настраивала команда, свой личный вклад и конкретные решения сейчас описать не могу. Метрики не помню.


Назначение `follow_up` из исходной оценки:

```json

[
  {
    "trigger": "missing_detail",
    "prompt": "Могли бы вы подробно описать ваш конкретный личный вклад в настройку архитектуры и надёжность обработки сообщений в проекте с использованием Python, FastAPI и Kafka?",
    "reason": "Необходимо уточнить конкретный личный вклад кандидата для оценки технической глубины и соответствия вакансии.",
    "criterion_ids": [
      "technical_depth",
      "primary_vacancy_fit"
    ],
    "requirement_ids": [
      "req-python",
      "req-framework",
      "req-kafka"
    ],
    "resume_claim_ids": []
  }
]

```

## Полный результат классификатора

```json

{
  "candidate_id": "PY-008",
  "profile": "Сильные заявления без деталей",
  "target": "следует уточнить",
  "target_reason": "Резюме выглядит релевантно, но ответ не позволяет подтвердить личный вклад.",
  "prediction": "следует уточнить",
  "correct": true,
  "technical": {
    "label": "weak",
    "value": -0.5,
    "confidence": 0.8,
    "explanation": "The candidate lists relevant technologies (Python, FastAPI, Kafka, PostgreSQL, Kubernetes) and notes the project was large and high-load, but does not describe specific personal contributions, architectural decisions, or reliability improvements. No concrete example of production solution design or trade-offs, nor measurable results were provided, limiting confidence in technical depth."
  },
  "vacancy_fit": {
    "label": "weak",
    "value": -0.5,
    "confidence": 0.75,
    "explanation": "The answer mentions technologies required by the vacancy (Python, FastAPI, Kafka, PostgreSQL, Kubernetes), indicating some relevance. However, lack of details about own contributions, handling of mandatory topics like schema design, Kafka production-grade usage, observability, and measurable impact reduce clarity on full fit to mandatory requirements."
  },
  "follow_up_count": 1,
  "follow_up": [
    "Могли бы вы подробно описать ваш конкретный личный вклад в настройку архитектуры и надёжность обработки сообщений в проекте с использованием Python, FastAPI и Kafka?"
  ],
  "attempts": 1,
  "resume": "Заявлены 6 лет Python, Kafka, Kubernetes, PostgreSQL и FastAPI.",
  "answer": "Работал с Python, FastAPI, Kafka, PostgreSQL и Kubernetes. Проект был большой и нагруженный, всё работало хорошо. Архитектуру и надёжность настраивала команда, свой личный вклад и конкретные решения сейчас описать не могу. Метрики не помню.",
  "raw_assessment": {
    "schema_version": "session_agent_output_v2",
    "purpose": "answer_assessment",
    "response_id": "681ce2c2-32ca-52af-afda-f6f6d3e7af06",
    "question_id": "cbdae577-cae3-5647-9900-f56fddf2f4c8",
    "observations": [
      {
        "criterion_id": "technical_depth",
        "dimension": "technical",
        "label": "weak",
        "value": -0.5,
        "confidence": 0.8,
        "explanation": "The candidate lists relevant technologies (Python, FastAPI, Kafka, PostgreSQL, Kubernetes) and notes the project was large and high-load, but does not describe specific personal contributions, architectural decisions, or reliability improvements. No concrete example of production solution design or trade-offs, nor measurable results were provided, limiting confidence in technical depth.",
        "evidence": [
          {
            "kind": "counter",
            "evidence_id": "answer:681ce2c2-32ca-52af-afda-f6f6d3e7af06:001"
          }
        ]
      },
      {
        "criterion_id": "primary_vacancy_fit",
        "dimension": "vacancy_fit",
        "label": "weak",
        "value": -0.5,
        "confidence": 0.75,
        "explanation": "The answer mentions technologies required by the vacancy (Python, FastAPI, Kafka, PostgreSQL, Kubernetes), indicating some relevance. However, lack of details about own contributions, handling of mandatory topics like schema design, Kafka production-grade usage, observability, and measurable impact reduce clarity on full fit to mandatory requirements.",
        "evidence": [
          {
            "kind": "counter",
            "evidence_id": "answer:681ce2c2-32ca-52af-afda-f6f6d3e7af06:001"
          }
        ]
      }
    ],
    "follow_up": [
      {
        "trigger": "missing_detail",
        "prompt": "Могли бы вы подробно описать ваш конкретный личный вклад в настройку архитектуры и надёжность обработки сообщений в проекте с использованием Python, FastAPI и Kafka?",
        "reason": "Необходимо уточнить конкретный личный вклад кандидата для оценки технической глубины и соответствия вакансии.",
        "criterion_ids": [
          "technical_depth",
          "primary_vacancy_fit"
        ],
        "requirement_ids": [
          "req-python",
          "req-framework",
          "req-kafka"
        ],
        "resume_claim_ids": []
      }
    ],
    "live_coding": null
  }
}

```
